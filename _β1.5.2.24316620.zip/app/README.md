# Evades Region Editor
This is a visual editor where you can import your maps.

## Region files from Evades.io
The region files are currently cached from Google Drive folder "Evades.io Map Files".

## Necessary fonts used for rendering Evades.io
Fonts are from Microsoft Corporation and Monotype Corporation
* Tahoma 7.04
* Arial 7.03