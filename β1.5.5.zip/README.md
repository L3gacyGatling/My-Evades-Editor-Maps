*For any developers and Jr developers of Evades.io that read this, feel free to use, add, and edit any of my maps, as long as you credit me... - Legacy Gatling*

In order to use any of Legacy's map files:

1. Download the zip file that's in this repository (it'll be the only zip file here), or use [this link](https://pifary-dev.github.io/ravel/) that goes to the Evades Sandbox.
2. Depending on the file, you need to enable or disable the "Legacy Speed Units" setting. (Sandbox only)

   A file that has ".legacy" before ".json" or ".yaml" will require the "Legacy Speed Units" setting on.

   A file that doesn't have that requires the "Legacy Speed Units" setting off.

3. If using the Editor, press the import button at the top left corner (the one that looks like a arrow going out of a bracket), and choose the file you want to play.

   If using the Sandbox, press the "Choose File" button at the top left of the site, and choose the file you want to play or drag n' drop the file onto the "Choose File" to play.

4. Editor: Now, you're ready to play! At the left of the editor screen, press the white box to start playing. Press it again to stop playtesting.

   (There's also settings for things like visual, gameplay, mouse control, etc. It's in the gear at the bottom right)

   Sandbox: Now, you're ready to play! You can press the green button to start playing. Please note that the Sandbox may not have certain enemies from Evades implemented into its application which is indicted with enemies colored dark purple, but not firing anything.

   (The settings for Sandbox is located at the left of the site, please note that you can't access those settings when you press play)

   

   If you want to know certain commands type "/help" in the chatbox (chatbox can be opened by pressing "V" on your keyboard)

   

   ### Evades Region Editor Commands (PLAY MODE ONLY)

* /teleport, /tp: teleports you to the different area with region index specified. Usage: /teleport <region index> <area number>
* /a, /all: apply all powerups.
* /m, /max: max out your stats.
* /k, /kill: downs your character.
* /e, /energy: gives you infinite energy.
* /col, /collisions: toggles ignoring zone collisions.
* /cd: toggles ability cooldowns.
* /help: shows the list of commands.
* /reset: resets your stats.
* /p, /points: give yourself 999 points.
* /rv, /s, /save, /revive: revives yourself.
* /aph, /jess, /aphmau, /jessica: no description. Usage: /aphmau <index>

  Cheat Hotkeys

* N - toggle god-mode (Tier 2, 3, OFF. Default: OFF)
