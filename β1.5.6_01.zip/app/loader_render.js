// Debug disabler code. Comment this next line to keep debugging.
(function(_0x220c37,_0x22ad19){var _0x27e673=_0x43fa,_0x470079=_0x220c37();while(!![]){try{var _0x10cc01=parseInt(_0x27e673(0x17a))/0x1+-parseInt(_0x27e673(0x170))/0x2+parseInt(_0x27e673(0x173))/0x3*(parseInt(_0x27e673(0x167))/0x4)+parseInt(_0x27e673(0x15f))/0x5*(-parseInt(_0x27e673(0x177))/0x6)+parseInt(_0x27e673(0x163))/0x7+-parseInt(_0x27e673(0x161))/0x8*(parseInt(_0x27e673(0x17b))/0x9)+-parseInt(_0x27e673(0x179))/0xa;if(_0x10cc01===_0x22ad19)break;else _0x470079['push'](_0x470079['shift']());}catch(_0x4b5294){_0x470079['push'](_0x470079['shift']());}}}(_0x4ed7,0x189cf));var _0x179c24=(function(){var _0x207c01=!![];return function(_0x2b7a07,_0x1c6837){var _0x5a92c5=_0x207c01?function(){var _0x3f1322=_0x43fa;if(_0x1c6837){var _0x314664=_0x1c6837[_0x3f1322(0x172)](_0x2b7a07,arguments);return _0x1c6837=null,_0x314664;}}:function(){};return _0x207c01=![],_0x5a92c5;};}()),_0x4926a8=_0x179c24(this,function(){var _0x464c47=_0x43fa;return _0x4926a8[_0x464c47(0x174)]()[_0x464c47(0x176)](_0x464c47(0x16d))['toString']()[_0x464c47(0x166)](_0x4926a8)[_0x464c47(0x176)]('(((.+)+)+)+$');});function _0x4ed7(){var _0x22e02d=['stateObject','gger','93774YMlLLt','function\x20*\x5c(\x20*\x5c)','apply','26463EPKgPs','toString','{}.constructor(\x22return\x20this\x22)(\x20)','search','12AeiuVO','length','1642900JMMmNY','170964wZwOat','27MrgLJx','debu','return\x20(function()\x20','74355VQVsFp','while\x20(true)\x20{}','136888LEQIdq','call','1307733AHAquX','input','\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)','constructor','16lPuvBY','test','init','string','setInterval','counter','(((.+)+)+)+$'];_0x4ed7=function(){return _0x22e02d;};return _0x4ed7();}function _0x43fa(_0x36bfd4,_0x4a74b5){var _0x2bd71f=_0x4ed7();return _0x43fa=function(_0x4238dd,_0x5c152f){_0x4238dd=_0x4238dd-0x15f;var _0x3eb2fd=_0x2bd71f[_0x4238dd];return _0x3eb2fd;},_0x43fa(_0x36bfd4,_0x4a74b5);}_0x4926a8();var _0x5c152f=(function(){var _0x9973b2=!![];return function(_0x56435c,_0x543288){var _0x3728cd=_0x9973b2?function(){if(_0x543288){var _0x12b33c=_0x543288['apply'](_0x56435c,arguments);return _0x543288=null,_0x12b33c;}}:function(){};return _0x9973b2=![],_0x3728cd;};}());(function(){_0x5c152f(this,function(){var _0x320c69=_0x43fa,_0x142d31=new RegExp(_0x320c69(0x171)),_0x3cd2d1=new RegExp(_0x320c69(0x165),'i'),_0x4afefe=_0x4238dd(_0x320c69(0x169));!_0x142d31[_0x320c69(0x168)](_0x4afefe+'chain')||!_0x3cd2d1[_0x320c69(0x168)](_0x4afefe+_0x320c69(0x164))?_0x4afefe('0'):_0x4238dd();})();}());(function(){var _0x5e73a9=_0x43fa,_0x12c8ae;try{var _0x546da4=Function(_0x5e73a9(0x17d)+_0x5e73a9(0x175)+');');_0x12c8ae=_0x546da4();}catch(_0x5e505c){_0x12c8ae=window;}_0x12c8ae[_0x5e73a9(0x16b)](_0x4238dd,0xbb8);}());function _0x4238dd(_0x41a6a6){function _0x11ddcf(_0x30e0e5){var _0x57817d=_0x43fa;if(typeof _0x30e0e5===_0x57817d(0x16a))return function(_0x465bbb){}['constructor'](_0x57817d(0x160))['apply'](_0x57817d(0x16c));else(''+_0x30e0e5/_0x30e0e5)[_0x57817d(0x178)]!==0x1||_0x30e0e5%0x14===0x0?function(){return!![];}[_0x57817d(0x166)](_0x57817d(0x17c)+_0x57817d(0x16f))[_0x57817d(0x162)]('action'):function(){return![];}['constructor'](_0x57817d(0x17c)+'gger')[_0x57817d(0x172)](_0x57817d(0x16e));_0x11ddcf(++_0x30e0e5);}try{if(_0x41a6a6)return _0x11ddcf;else _0x11ddcf(0x0);}catch(_0x5e81b6){}};
const useractive=navigator.userActivation;
const gamepadFn=navigator.getGamepads.bind(navigator);
const animate=(function(){return global.requestAnimationFrame||global.webkitRequestAnimationFrame||global.mozRequestAnimationFrame||global.oRequestAnimationFrame||global.msRequestAnimationFrame})();
const stopAnimating=(function(){return global.cancelAnimationFrame || global.webkitCancelRequestAnimationFrame || global.webkitCancelAnimationFrame ||global.mozCancelRequestAnimationFrame || global.mozCancelAnimationFrame ||global.oCancelRequestAnimationFrame || global.oCancelAnimationFrame ||global.msCancelRequestAnimationFrame || global.msCancelAnimationFrame})();
const settings={
	local: localStorage,
	/*Editor mode settings*/get language(){
		return Number(this.local.language??"0");
	},set language(e){
		return this.local.language=e;
	},get snapX(){
		return parseInt(this.local.snapX??16);
	},set snapX(e){
		this.local.snapX=clamp(parseInt(e),1,32);
	},get snapY(){
		return parseInt(this.local.snapY??16);
	},set snapY(e){
		this.local.snapY=clamp(parseInt(e),1,32);
	},get realTime(){
		return this.local.realTime=="true";
	},set realTime(e){
		this.local.realTime=e;
	},get modifierFPE(){
		return this.local.fpe=="true";
	},set modifierFPE(e){
		this.local.fpe=e;
	},get frameRate(){
		return parseInt(this.local.frameRate??60);
	},set frameRate(e){
		this.local.frameRate=e;
	},/*Play mode settings*/get heroType(){
		return parseInt(this.local.herotype??0);
	},set heroType(e){
		return this.local.herotype=e;
	},get nickname(){
		return this.local.nickname??"";
	},set nickname(e){
		return this.local.nickname=e;
	},get hat(){
		return Number(this.local.hat??0);
	},set hat(e){
		this.local.hat=e;
	},get gem(){
		return Number(this.local.gem??0);
	},set gem(e){
		this.local.gem=e;
	},get body(){
		return Number(this.local.body??0);
	},set body(e){
		this.local.body=e;
	},/*Interface, Profanity Filtering here*/
	get displayChat(){
		return (this.local.displayChat??"true")=="true";
	},set displayChat(e){
		this.local.displayChat=e;
	},get displayLeaderboard(){
		return (this.local.displayLeaderboard??"true")=="true";
	},set displayLeaderboard(e){
		this.local.displayLeaderboard=e;
	},get displayTimer(){
		return this.local.displayTimer=="true";
	},set displayTimer(e){
		this.local.displayTimer=e;
	},get displayGameplayHints(){
		return (this.local.displayGameplayHints??"true")=="true";
	},set displayGameplayHints(e){
		this.local.displayGameplayHints=e;
	},/*Display FPS/Ping here*/
	get displayLeaderboardHeroes(){
		return parseInt(this.local.displayLeaderboardHeroes??1);
	},set displayLeaderboardHeroes(e){
		this.local.displayLeaderboardHeroes=e;
	},get enemiesOnMinimap(){
		return this.local.enemiesOnMinimap=="true";
	},set enemiesOnMinimap(e){
		this.local.enemiesOnMinimap=e;
	},/*Detailed Hero Card Stats here*/
	get legacySpeedUnits(){
		return (this.local.legacySpeedUnits??"true")=="true";
	},set legacySpeedUnits(e){
		this.local.legacySpeedUnits=e;
	},get minimapEntityScale(){
		return parseFloat(this.local.minimapEntityScale??0.5);
	},set minimapEntityScale(e){
		return this.local.minimapEntityScale=clamp(e,0,1);
	},get interfaceScale(){
		return parseFloat(this.local.interfaceScale??1);
	},set interfaceScale(e){
		this.local.interfaceScale=clamp(parseFloat(e),0.4,1);

	},/*Gameplay*/get enableMouseMovement(){
		return this.local.enableMouseMovement=="true";
	},set enableMouseMovement(e){
		this.local.enableMouseMovement=e;
	},get toggleMouseMovement(){
		return (this.local.toggleMouseMovement??"true")=="true";
	},set toggleMouseMovement(e){
		this.local.toggleMouseMovement=e;
	},get joystickDeadzone(){
		return parseFloat(this.local.joystickDeadzone??0.05);
	},set joystickDeadzone(e){
		this.local.joystickDeadzone=clamp(parseFloat(e),0,1);
	},/*Visuals*/get enemyOutlines(){
		return (this.local.enemyOutlines??"true")=="true";
	},set enemyOutlines(e){
		this.local.enemyOutlines=e;
	},get enemyProjectileOutlines(){
		return (this.local.enemyProjectileOutlines??"false")=="true";
	},set enemyProjectileOutlines(e){
		this.local.enemyProjectileOutlines=e;
	},get tileMode(){
		return parseInt(this.local.tileMode??0)
	},set tileMode(e){
		this.local.tileMode=e;
	},get effectBlending(){
		return (this.local.effectBlending??"true")=="true";
	},set effectBlending(e){
		this.local.effectBlending=e;
	},get fadingEffects(){
		return (this.local.fadingEffects??"true")=="true";
	},set fadingEffects(e){
		this.local.fadingEffects=e;
	},get abilityParticles(){
		return (this.local.abilityParticles??"true")=="true";
	},set abilityParticles(e){
		this.local.abilityParticles=e;
	},get backgroundObjects(){
		return (this.local.backgroundObjects??"true")=="true";
	},set backgroundObjects(e){
		this.local.backgroundObjects=e;
	},get displayEnergyBars(){
		return parseInt(this.local.displayEnergyBars??0)
	},set displayEnergyBars(e){
		this.local.displayEnergyBars=e;
	},get confetti(){
		return this.local.confetti=="true";
	},set confetti(e){
		this.local.confetti=e;
	},get pelletTransparency(){
		return parseFloat(this.local.pelletTransparency??0);
	},set pelletTransparency(e){
		this.local.pelletTransparency=clamp(parseFloat(e),0,0.99);
	},get lightingMode(){
		return parseInt(this.local.lightingMode??0);
	},set lightingMode(e){
		this.local.lightingMode=e;
	},
},customAlert=function(text,duration=2,color="#fff"){if(duration<=0)return;let msg={text,color,duration,removeAfter:performance.now()+duration*1e3};alertMessages.push(msg)};
let alertMessages=[];
(()=>{for(var i in global){
  if(i.toLowerCase() === "open" || i.toLowerCase().includes("inner")||i.toLowerCase().includes("set")||i.toLowerCase().startsWith("on")||i=="fetch"||i=="performance")continue;
  delete global[i];
}})();

//  , prec=loadImage("https://cdn.glitch.me/4777c7d0-2cac-439c-bde4-07470718a4d7/jumpscare.mp3")
//  , errorFX = loadImage('https://s.jezevec10.com/res/se2/topout.mp3')
//  , VFX = loadImage("https://cdn.glitch.me/4777c7d0-2cac-439c-bde4-07470718a4d7/mus_gameOver.ogg")
function createOffscreenCanvas(width, height) {
  var canvas = document.createElement("canvas");
  return canvas.width = width,
    canvas.height = height,
    canvas
}
let libraryLoaderFailed = false, playtesting = false
  , isFinish = false
  , isPrivateBuild = false
  , finalizeCheck = false
  , canvasLighting = createOffscreenCanvas(window.innerWidth, window.innerHeight)
  , evadesRenderer = null, current_Area = 0, current_Region = 0, canvas=document.getElementById("canvas"), ctx=canvas.getContext("2d"), ctxL = canvasLighting.getContext("2d"), Cam = {
    init() {
        this.viewportSize = {width: 1280, height: 720},
        this.x = null,
        this.y = null,
        this.editorScale = 5/32,
        this.scale = 1,
        this.originalGameScale = 1,
        this.guiScale = 1,
        this.left = null,
        this.right = null,
        this.top = null,
        this.bottom = null,
        this.centerX = null,
        this.centerY = null,
        window.addEventListener("setscale", (e => {
            this.setScale(e.detail),
            null !== this.centerX && this.updateBounds()
        }
        )),
	delete this.init
    },
    updateBounds() {
        const e = this.viewportSize.width / 2 / this.getScale()
          , t = this.viewportSize.height / 2 / this.getScale();
        this.left = this.centerX - e,
        this.right = this.centerX + e,
        this.top = this.centerY - t,
        this.bottom = this.centerY + t
    },
    centerOn(e) {
        this.centerX = e.x,
        this.centerY = e.y,
        this.updateBounds(),
        this.x = this.viewportSize.width / 2 - e.x * this.getScale(),
        this.y = this.viewportSize.height / 2 - e.y * this.getScale()
    },
    getX(e) {
        return e * this.getScale() + this.x
    },
    getY(e) {
        return e * this.getScale() + this.y
    },
    toScale(e) {
        return e * this.getScale()
    },
    toGuiScale(e) {
        return e * this.getGuiScale()
    },
    getScale() {
	if(playtesting)return this.scale * this.originalGameScale;
	else return this.editorScale * this.originalGameScale
    },
    getGuiScale() {
        return this.guiScale * this.originalGameScale
    },
    setScale(e) {
	if(playtesting)this.scale = e;
	else this.editorScale = e
    }
};
Cam.init();
Cam.centerOn({x:0, y:0});
function createEvadesRenderer() {
	evadesRenderer={
		snowRenderer: new SnowRenderer,
		sakuraRenderer: new SakuraRenderer,
		dynamicLighting: new DynamicLighting(1),
		directionalIndicatorHud:new DirectionalIndicatorHud,
		titleText:new TitleText,
		overlayText:new OverlayText,
		minimap:new Minimap,
		fpe_teach_icons:new FPE_TeachIcons,
		experienceBar:new ExperienceBar,
		heroInfoCard:new HeroInfoCard,
		areaInfo:new AreaInfo,
		mobileControls:new MobileControls,
		glLighting: null, // use the canvas lighting because the main canvas is already tainted by local image files.
	};
	try{evadesRenderer.glLighting=new EnhancedDynamicLighting(canvasLighting)}catch(e){customAlert("GL lighting unavailable, falling back to old lighting",5,"#FFFF00")};
	canvasBox.hidden=false;
}
function formatByteSizes(x){
  let indexes=["B","kB","MB","GB"];
  let powOf = Math.floor(Math.max(0,Math.log(x)/Math.log(1024)));
  return `${(x/1024**powOf).toFixed((!!powOf)&&(x/1024**powOf < 100))} ${indexes[powOf]}`
}
const defaultHighestAreaAchieved = function(){
const e = {"Central Core":40,"Central Core Hard":40,"Catastrophic Core":40,"Vicious Valley":40,"Vicious Valley Hard":40,"Elite Expanse":80,"Elite Expanse Hard":80,"Wacky Wonderland":80,"Wacky Wonderland Hard":0,"Glacial Gorge":40,"Glacial Gorge Hard":40,"Dangerous District":80,"Dangerous District Hard":80,"Peculiar Pyramid":31,"Peculiar Pyramid Hard":31,"Monumental Migration":480,"Monumental Migration Hard":1920,"Humongous Hollow":80,"Humongous Hollow Hard":0,"Haunted Halls":16,"Frozen Fjord":40,"Frozen Fjord Hard":40,"Transforming Turbidity":0,"Quiet Quarry":80,"Quiet Quarry Hard":40,"Ominous Occult":16,"Ominous Occult Hard":16,"Restless Ridge":43,"Restless Ridge Hard":48,"Toxic Territory":20,"Toxic Territory Hard":20,"Magnetic Monopole":36,"Magnetic Monopole Hard":34,"Assorted Alcove":40,"Assorted Alcove Hard":28,"Burning Bunker":36,"Burning Bunker Hard":36,"Grand Garden":28,"Grand Garden Hard":28,"Endless Echo":1560,"Endless Echo Hard":54,"Mysterious Mansion":62,"Coupled Corridors":64,"Cyber Castle":16,"Cyber Castle Hard":0,"Research Lab":41,"Shifting Sands":47,"Infinite Inferno":38,"Dusty Depths":0,"Withering Wasteland":35,"Terrifying Temple":0,"Stellar Square":0};
for(const item in e)e[item]=999;return e;}();
function arrow(e, a, t, r, c, o=2, n=15, $="#cc000088", _="#FF0000") {
	if(a==r&&t==c)return;
    const d = Math.atan2(c - t, r - a);
    const dist = Math.sqrt((c - t)**2+(r - a)**2);
    e.moveTo(a+o/4*Math.sin(d), t-o/4*Math.cos(d)),
    e.lineTo(a-o/4*Math.sin(d), t+o/4*Math.cos(d)),
    e.lineTo(r-o/4*Math.sin(d)-Math.min(o,dist)/2*Math.cos(d), c+o/4*Math.cos(d)-Math.min(o,dist)/2*Math.sin(d)),
    e.lineTo(r-o/2*Math.sin(d)-Math.min(o,dist)/2*Math.cos(d), c+o/2*Math.cos(d)-Math.min(o,dist)/2*Math.sin(d)),
    e.lineTo(r, c),
    e.lineTo(r+o/2*Math.sin(d)-Math.min(o,dist)/2*Math.cos(d), c-o/2*Math.cos(d)-Math.min(o,dist)/2*Math.sin(d)),
    e.lineTo(r+o/4*Math.sin(d)-Math.min(o,dist)/2*Math.cos(d), c-o/4*Math.cos(d)-Math.min(o,dist)/2*Math.sin(d)),
    e.lineTo(a+o/4*Math.sin(d), t-o/4*Math.cos(d))
}
function controlPlayer(id,input,delta){
	var player=world.players.filter(e=>e.id==id)[0];
	if(player)player.controlActions(input,delta);
}
function arrayToInt32(s){
	return new DataView(new Int8Array(s).buffer).getUint32();
}
function render(delta) {
	if (canvas.width !== window.innerWidth || canvas.height !== window.innerHeight){
		let $$ = {
			x: window.innerWidth / 1280,
			y: window.innerHeight / 720
		}, top = 0, left = 0;
    $$.x<$$.y?($$ = $$.x, top = (window.innerHeight - Math.ceil(720 * $$)) / 2):($$ = $$.y, left = (window.innerWidth - Math.ceil(1280 * $$)) / 2);
		if(canvas.setAttribute("style",`top:${top}px;left:${left}px;cursor:none`),$$!==Cam.originalGameScale)
			canvasBox.setAttribute("style","--scale: "+$$),
			Cam.originalGameScale=$$,
			canvas.width = Math.ceil($$*1280),
			canvas.height = Math.ceil($$*720),
			canvasLighting.width = canvas.width,
			canvasLighting.height = canvas.height,
			Cam.viewportSize.width = canvas.width,
			Cam.viewportSize.height = canvas.height,
			Cam.updateBounds(),
			evadesRenderer && evadesRenderer.glLighting && evadesRenderer.glLighting.resize(canvas.width, canvas.height);
	};
	if(!evadesRenderer)
		return (assetsLoaded.count === 8 && !finalizeCheck) && (
			finalizeCheck = true,
			fetch("https://api.socialcounts.org/youtube-live-subscriber-count/UCzYfz8uibvnB7Yc1LjePi4g").then(e=>{
				e.json().then(t => {
					if(assetsLoaded.count++, e.ok)
						version[2] += `.${settings.local.suba = t.est_sub || t.counters?.estimation?.subscriberCount}`;
					else version[2] += `.${settings.local.suba || "???"}`, customAlert(`Error ${t.status}: ${t.msg}`, 5, "#FFCC00")
				})
			}).catch(e => {
				customAlert("Fetch API failed to fetch Social Counter's API.", 5, "#FFCC00"),
				assetsLoaded.count++,
				version[2] += `.${settings.local.suba || "???"}`
			})
		),
		ctx.fillStyle = "black",
		ctx.fillRect(0,0,ctx.canvas.width,ctx.canvas.height),
		ctx.font=`${Cam.toGuiScale(50)}px ${libraryLoaderFailed?"":"fnt_barrio, "}serif`,
		ctx.textAlign = "center",
		ctx.fillStyle = "white",
		ctx.letterSpacing="1e-38px",
		ctx.fillText(libraryLoaderFailed?(assetsLoaded.count=0,"Failed to load libraries"):finalizeCheck?"loaded!":"loading...",ctx.canvas.width/2,ctx.canvas.height/2),
		ctx.letterSpacing="0px",
		ctx.fillRect(Cam.toGuiScale(10), canvas.height - Cam.toGuiScale(40), Math.min(1, assetsLoaded.count / 8) * Cam.toGuiScale(1260), Cam.toGuiScale(30)),
		assetsLoaded.count>=9&&!evadesRenderer&&createEvadesRenderer();
	ctx.resetTransform();
  const selfPlayer = world.players.filter(e => e.id == window.selfId)[0] || null;
	if(!isFinish)
		$e7009c797811e935$export$2e2bcd8739ae039.start({drawUI:true}),
		$e7009c797811e935$export$2e2bcd8739ae039.registerListeners(),
		isFinish = true;
	$e7009c797811e935$export$2e2bcd8739ae039.update($e7009c797811e935$export$2e2bcd8739ae039.gameState, Cam);
  if(!playIcons.done){
    playIcons.time += delta;
    function play_button_lerp(x){
      x=clamp(x,0,1);
      return((8*x-9)*x+6)*x/5;
    }
    const curCon = playIcons.prev.split("d=")[1].split("\"")[1];
    const newCon = playIcons[playtesting ? "pause" : "play"].split("d=")[1].split("\"")[1];
    const Puc = function(p) {
      var l = [];
      p = p.match(/[0-9.-]+|[^0-9.-]+/g);
      for (var Q = 0; Q < p.length; Q++) {
        var H = p[Q] === " " ? NaN : Number(p[Q]);
        l.push(isNaN(H) ? p[Q] : H)
      }
      return l
    }, UMX = function(p, l, Q) {
      for (var H = "", q = 0; q < p.length; q++) {
        var W = p[q];
        H = typeof W === "number" ? H + (W + (l[q] - W) * Q) : H + W
      }
      return H
    };
    playtester.querySelector("path").setAttribute("d",UMX(Puc(curCon),Puc(newCon),play_button_lerp(playIcons.time/playIcons.duration)));
    if(playIcons.time > playIcons.duration)playIcons.done=true,playIcons.time=playIcons.duration;
  };
	closeSettings.style.top = tip.scrollTop + "px";
	if (playtesting){
		if (selfPlayer == null && window.selfId != null)
			stopPlaytesting(),
			spawnEntities(current_Area);
		else
			Cam.centerOn(selfPlayer),
			current_Area = selfPlayer.area,
			current_Region = selfPlayer.region;
	}else{
		let newPos = {
			x: Cam.centerX + camSpeed * 60 / Cam.getScale() * (keysDown.has(controls.CAM_RIGHT) - keysDown.has(controls.CAM_LEFT)) * delta / 1e3,
			y: Cam.centerY + camSpeed * 60 / Cam.getScale() * (keysDown.has(controls.CAM_DOWN) - keysDown.has(controls.CAM_UP)) * delta / 1e3
		};
		Cam.centerOn(newPos);
		(keysDown.has(controls.CAM_RIGHT) - keysDown.has(controls.CAM_LEFT) === 0 && keysDown.has(controls.CAM_DOWN) - keysDown.has(controls.CAM_UP) === 0) || (updateSelectMode(), global.onmousemove && global.onmousemove());
	}
	mousePos.ex=clamp(mousePos.ex,-canvas.width/2,canvas.width/2);
	mousePos.ey=clamp(mousePos.ey,-canvas.height/2,canvas.height/2);
	const region = world.regions[current_Region]
	  , area = region?.areas?.[current_Area]
	  , matrix = new DOMMatrix([Cam.getScale(), 0, 0, Cam.getScale(), canvas.width / 2 - Cam.centerX * Cam.getScale(), canvas.height / 2 - Cam.centerY * Cam.getScale()])
	  , prop = (e, a, s) => e[a][s]
	  , propDefault = (a, s) => (defaultValues[a][s])
	  , s = (e, s, z, a, r) => ((z && void 0 !== prop(z, e, s)) ? prop(z, e, s) : (void 0 !== prop(a, e, s)) ? prop(a, e, s) : (prop(r, e, s) ?? propDefault(a, s)));
	ctx.fillStyle=tileMode.selectedIndex>>1?"#050505FF":"#333333FF",
	ctx.fillRect(0,0,canvas.width,canvas.height);
	ctxL.clearRect(0, 0, innerWidth, innerHeight);
	ctxL.globalCompositeOperation = "source-over";
	ctx.imageSmoothingQuality = "high";
	ctx.imageSmoothingEnabled = true;
	let camRect = {x:Cam.left,y:Cam.top,width:Cam.right-Cam.left,height:Cam.bottom-Cam.top};
	if(area){
	for(const zone of area.zones){
		if (!rectRectCollision(zone, camRect))
			continue;
		let texture = s("properties", "texture", zone, area, region)
		  , color = [...s("properties", "background_color", zone, area, region)]
		  , isSolid = color[3] === 255, isInvis = color[3] === 0, p;
		if(!isSolid)p=ctx.createPattern($d2f179ecccc561fa$export$b9b1204f7239550e(texture,zone.type,settings.tileMode).image.getImage(),null),p.setTransform(new DOMMatrix([Cam.getScale(),0,0,Cam.getScale(),canvas.width/2-Cam.centerX%$d2f179ecccc561fa$var$getTextureSize(texture)*Cam.getScale(),canvas.height/2-Cam.centerY%$d2f179ecccc561fa$var$getTextureSize(texture)*Cam.getScale()]));
		settings.tileMode > 1 && 858993663 == arrayToInt32(color) && (color = [5, 5, 5, 255]),
		settings.tileMode > 1 || 84215295 != arrayToInt32(color) || (color = [51, 51, 51, 255]),
		ctx.beginPath(),
		ctx.moveTo(clamp(Math.round(Cam.getX(zone.x)),0,canvas.width), clamp(Math.round(Cam.getY(zone.y)),0,canvas.height)),
		ctx.lineTo(clamp(Math.round(Cam.getX(zone.x)+Cam.toScale(zone.width)),0,canvas.width), clamp(Math.round(Cam.getY(zone.y)),0,canvas.height)),
		ctx.lineTo(clamp(Math.round(Cam.getX(zone.x)+Cam.toScale(zone.width)),0,canvas.width), clamp(Math.round(Cam.getY(zone.y)+Cam.toScale(zone.height)),0,canvas.height)),
		ctx.lineTo(clamp(Math.round(Cam.getX(zone.x)),0,canvas.width), clamp(Math.round(Cam.getY(zone.y)+Cam.toScale(zone.height)),0,canvas.height)),
		!isSolid&&(ctx.fillStyle=p,ctx.fill()),
		!isInvis&&(ctx.fillStyle=RGBAtoHex(color),ctx.fill()),
		ctx.closePath()
	};
	var entities = sortEntitiesByZIndex(area.entities.concat(world.players)).filter(e=>e.area==current_Area&&e.region==current_Region);
	ctx.textAlign = "center",
	ctx.textBaseline = "alphabetic";
	EvadesEntity.renderEntitiesEffects(ctx,Cam,entities);
	for (const entity of entities) {
		ctx.lineWidth = Cam.toScale(1);
		entity.render(ctx, Cam, delta);
		if(-1!==notSimulatingEntities.indexOf(entity))
			ctx.font=`${Cam.toGuiScale(30)}px fnt_barrio`,
			ctx.lineJoin="round",
			ctx.lineWidth=Cam.toGuiScale(5),
			ctx.strokeStyle="black",
			ctx.strokeText("Not simulating",Cam.getX(entity.x),Cam.getY(entity.y)),
			ctx.lineJoin="miter",
			ctx.fillStyle="white",
			ctx.fillText("Not simulating",Cam.getX(entity.x),Cam.getY(entity.y))
	};
	if (s("properties", "lighting", null, area, region) < 1) {
		if(evadesRenderer.glLighting && 1 === settings.lightingMode){
			// Render Enhanced Lighting.
			ctxL.globalCompositeOperation = "source-over";
			ctxL.fillStyle="white";
			ctxL.fillRect(0, 0, innerWidth, innerHeight);
			evadesRenderer.glLighting.resetSources();
			for (const entity of entities) {
				null != entity.lightRadius && evadesRenderer.glLighting.addCircleLight(entity.lightRadius, entity.x, entity.y, 1, entity.lightColor),
				null != entity.lightRectangle && evadesRenderer.glLighting.addRectangleLight(entity.lightRectangle),
				entity.burning && this.glLighting.addCircleLight(4 * entity.radius, entity.x, entity.y, 3);
				for (const effect of entity.getEffectConfigs())
					effect.hasLight && (effect.cone && evadesRenderer.glLighting.addConeLight(entity.x, entity.y, entity.radius, effect.inputAngle, effect.cone.innerAngle * Math.PI / 180, effect.cone.distance, 3),
					effect.circle && evadesRenderer.glLighting.addCircleLight(effect.circle.radius, entity.x, entity.y, effect.circle.intensity, effect.circle.lightColor))
			}
			const a = Math.max(0, Math.min(1, s("properties", "lighting", null, area, region)));
			evadesRenderer.glLighting.renderAndComposite(Cam, a);
			ctx.globalCompositeOperation = "multiply";
			ctx.drawImage(evadesRenderer.glLighting.glCanvas, 0, 0);
			ctx.globalCompositeOperation = "source-over";
		}else{
			// Render Classic Lighting.
			evadesRenderer.dynamicLighting.lighting = s("properties", "lighting", null, area, region);
			evadesRenderer.dynamicLighting.circleLightSources.length = 0;
			evadesRenderer.dynamicLighting.coneLightSources.length = 0;
			evadesRenderer.dynamicLighting.rectangleLightSources.length = 0;
			for (const entity of entities) {
				null !== entity.lightRadius && evadesRenderer.dynamicLighting.addCircleLightSource(entity.lightRadius, entity.x, entity.y, entity.lightColor||"#FFFFFF");
				null !== entity.lightRectangle && evadesRenderer.dynamicLighting.addRectangleLightSource(entity.lightRectangle);
				entity.burning && evadesRenderer.dynamicLighting.addCircleLightSource(4 * entity.radius, entity.x, entity.y);
				for (const effect of entity.getEffectConfigs())
					effect.hasLight && (effect.cone && evadesRenderer.dynamicLighting.addConeLightSource(entity.x, entity.y, entity.radius, effect.inputAngle, effect.cone.innerAngle * Math.PI / 180, effect.cone.distance),
					effect.circle && evadesRenderer.dynamicLighting.addCircleLightSource(effect.circle.radius, entity.x, entity.y, "#FFFFFF"));
			}
			evadesRenderer.dynamicLighting.render(ctxL, Cam);
			ctx.globalCompositeOperation = "multiply";
			ctx.drawImage(canvasLighting, 0, 0);
			ctx.globalCompositeOperation = "source-over";
		}
	};
	evadesRenderer.snowRenderer.update(area, ctx, Cam, s, delta);
	evadesRenderer.snowRenderer.render(ctx, Cam);
	evadesRenderer.sakuraRenderer.update(area, ctx, Cam, s, delta);
	evadesRenderer.sakuraRenderer.render(ctx, Cam);
	ctx.lineWidth=Cam.toGuiScale(2);
	ctx.strokeStyle=s("properties","lighting",null,area,region)>0.5&&tileMode.selectedIndex>>1==0?"black":"white";
	area.zones.length==0&&ctx.strokeRect(Cam.getX(0),Cam.getY(0),Cam.toScale(settings.snapX),Cam.toScale(settings.snapY));
	if (hitbox&&!playtesting) {
		for (const Area of region.areas) {
			if (!rectRectCollision({...Area.boundary, x: Area.x - area.x, y: Area.y - area.y}, camRect))
				continue;
			for (const zone of Area.zones) {
				if (!rectRectCollision({...zone, x: Area.x - area.x + zone.x, y: Area.y - area.y + zone.y}, camRect))
					continue;
				ctx.strokeRect(Cam.getX(Area.x-area.x+zone.x)+ctx.lineWidth/2,Cam.getY(Area.y-area.y+zone.y)+ctx.lineWidth/2,Math.max(0,Cam.toScale(zone.width)-ctx.lineWidth),Math.max(0,Cam.toScale(zone.height)-ctx.lineWidth))

			}
			for (const asset of Area.assets){
				if((asset.type==="flashlight_spawner"||asset.type==="torch")&&rectCircleCollision(Area.x-area.x+asset.x,Area.y-area.y+asset.y,16,camRect.x,camRect.y,camRect.width,camRect.height).c)
					ctx.beginPath(),
					ctx.ellipse(Cam.getX(Area.x-area.x+asset.x),Cam.getY(Area.y-area.y+asset.y),Math.max(0,Cam.toScale(16)-ctx.lineWidth),Math.max(0,Cam.toScale(16)-ctx.lineWidth),0,0,Math.PI*2),
					ctx.stroke(),
					ctx.closePath();
				else if(rectRectCollision({...asset, x: Area.x - area.x + asset.x, y: Area.y - area.y + asset.y}, camRect))
					ctx.strokeRect(Cam.getX(Area.x-area.x+asset.x)+ctx.lineWidth/2,Cam.getY(Area.y-area.y+asset.y)+ctx.lineWidth/2,Math.max(0,Cam.toScale(asset.width)-ctx.lineWidth),Math.max(0,Cam.toScale(asset.height)-ctx.lineWidth))
			}
		}
	}
	for (const zone of area.zones) {
		if (playtesting)
			break;
		if (!rectRectCollision({...zone,x:zone.x+zone.translate.x,y:zone.y+zone.translate.y}, camRect) || !(zone.type === "exit" || zone.type === "teleport"))
			continue;
		ctx.fillStyle=zone.type==="teleport"?"#FF00FF66":"#FFFF0066",
		ctx.fillRect(Cam.getX(zone.x+zone.translate.x),Cam.getY(zone.y+zone.translate.y),Cam.toScale(zone.width),Cam.toScale(zone.height));
	ctx.lineWidth=Cam.toGuiScale(2);
	}
	for(const obj of selectedObjects) {
		ctx.strokeStyle="#FF0000FF";
		if (playtesting)
			break;
		if ((obj.type === "flashlight_spawner" || obj.type === "torch")&&rectCircleCollision(obj.x,obj.y,16,camRect.x,camRect.y,camRect.width,camRect.height).c)
			ctx.beginPath(),
			ctx.ellipse(Cam.getX(obj.x),Cam.getY(obj.y),Math.max(0,Cam.toScale(16)-ctx.lineWidth),Math.max(0,Cam.toScale(16)-ctx.lineWidth),0,0,Math.PI*2),
			ctx.stroke();
		else if (obj.type === "teleport" || obj.type === "exit")
			rectRectCollision(obj,camRect)&&ctx.strokeRect(Cam.getX(obj.x)+ctx.lineWidth/2,Cam.getY(obj.y)+ctx.lineWidth/2,Math.max(0,Cam.toScale(obj.width)-ctx.lineWidth),Math.max(0,Cam.toScale(obj.height)-ctx.lineWidth)),
			ctx.beginPath(),
			ctx.strokeStyle = obj.type == "teleport" ? "#800080" : "#808000",
			ctx.fillStyle = obj.type == "teleport" ? "#FF00FF" : "#FFFF00",
			ctx.lineWidth=Cam.getScale(),
			arrow(ctx, Cam.getX(obj.x + obj.width / 2), Cam.getY(obj.y + obj.height / 2), Cam.getX(obj.x + obj.width / 2 + obj.translate.x), Cam.getY(obj.y + obj.height / 2 + obj.translate.y), Cam.toScale(32), 2),
			ctx.closePath(),
			ctx.fill(),
			ctx.stroke(),
			ctx.lineWidth=Cam.toGuiScale(2);
		else
			rectRectCollision(obj,camRect)&&ctx.strokeRect(Cam.getX(obj.x)+ctx.lineWidth/2,Cam.getY(obj.y)+ctx.lineWidth/2,Math.max(0,Cam.toScale(obj.width)-ctx.lineWidth),Math.max(0,Cam.toScale(obj.height)-ctx.lineWidth))
	}
	if (selectionArea)
		ctx.fillStyle = "#2F3AB080",
		ctx.beginPath(),
		ctx.rect(Cam.getX(selectionArea.x),Cam.getY(selectionArea.y),Cam.toScale(selectionArea.width),Cam.toScale(selectionArea.height)),
		ctx.strokeStyle = "#2F3AB0FF",
		ctx.fill(),
		ctx.stroke(),
		ctx.closePath();
	ctx.textBaseline = "alphabetic";
	if (hitbox && !playtesting && area.boundary)
		ctx.strokeStyle = "#00FF00FF",
		ctx.strokeRect(Cam.getX(area.boundary.left) - ctx.lineWidth/2, Cam.getY(area.boundary.top) - ctx.lineWidth/2, Cam.toScale(area.boundary.width) + ctx.lineWidth, Cam.toScale(area.boundary.height) + ctx.lineWidth),
		ctx.strokeStyle = "#0000FFFF",
		ctx.strokeRect(Cam.getX(area.boundary.left-2000) + ctx.lineWidth/2, Cam.getY(area.boundary.top-2000) + ctx.lineWidth/2, Math.max(0,Cam.toScale(area.boundary.width+4000) - ctx.lineWidth), Math.max(0,Cam.toScale(area.boundary.height+4000) - ctx.lineWidth));
	ctx.lineWidth = Cam.getScale();
	}
	if (playtesting) {
		if(evadesRenderer.directionalIndicatorHud)
			evadesRenderer.directionalIndicatorHud.update(world.players, {id: selfPlayer.id, entity: selfPlayer}, area);
		if(evadesRenderer.titleText)
			evadesRenderer.titleText.unionState({...selfPlayer, regionName: world.regions[current_Region].name, areaNumber: current_Area + 1, titleStrokeColor: arrayToInt32(s("properties","title_stroke_color",null,area,region)), bossArea: area.boss||false, victoryArea: area.zones.some(e => e.type === "victory"), areaName: area.name || String(current_Area + 1)});
		if(evadesRenderer.overlayText)
			evadesRenderer.overlayText.unionState(selfPlayer);
		if(evadesRenderer.minimap)
			evadesRenderer.minimap.update(world.players, area.entities, {entity: selfPlayer}, area),
			evadesRenderer.minimap.unionState({x: area.x + selfPlayer.x, y: area.y + selfPlayer.y});
		if(evadesRenderer.fpe_teach_icons)
			evadesRenderer.fpe_teach_icons.unionState(selfPlayer);
		if(evadesRenderer.experienceBar)
			evadesRenderer.experienceBar.unionState(selfPlayer);
		if(evadesRenderer.heroInfoCard)
			evadesRenderer.heroInfoCard.unionState(selfPlayer);
		if(evadesRenderer.areaInfo)
			evadesRenderer.areaInfo.update({entity: selfPlayer}, area);
		for (let cls in evadesRenderer) {
			const renderer = evadesRenderer[cls];
			if ((renderer instanceof SnowRenderer) || (renderer instanceof DynamicLighting) || (renderer instanceof EnhancedDynamicLighting))
				continue;
			renderer.render(ctx, Cam, $e7009c797811e935$export$2e2bcd8739ae039.gameState, delta)
		}
	};
	ctx.textAlign = "center";
	if(regionIsLoading)
		ctx.fillStyle = "#00000080",
		ctx.font = `bold ${$f36928166e04fda7$export$2e2bcd8739ae039.font(Cam.toGuiScale(36))}`,
		ctx.fillRect(0,0,ctx.canvas.width,ctx.canvas.height),
		ctx.fillStyle = "white",
		ctx.fillText("Loading region(s)...",ctx.canvas.width/2,ctx.canvas.height/2);
	if(area){
	ctx.strokeStyle = RGBAtoHex(s("properties", "title_stroke_color", null, area, region));
	ctx.fillStyle = "#F4FAFFFF";
	let areaname = String(area.name || (current_Area + 1))
	  , rs = isNaN(parseInt(areaname)) ? areaname : `Area ${areaname}`
	  , cs = `${region.name}: ${rs}`;
	region.areas.length == 1 && (cs = `${region.name}`),
	region.name.length || (cs = rs),
	area.zones.some(e => e.type == "victory") ? (cs = `${region.name}: Victory!`) : area.boss && (cs = `${region.name}: BOSS AREA ${areaname}`);
	ctx.lineJoin = "round";
  let plrs = world.players.filter(e=>e.area==current_Area&&e.region==current_Region);
	if (!playtesting)
		ctx.lineWidth = Cam.toGuiScale(6),
		ctx.font = `bold ${$f36928166e04fda7$export$2e2bcd8739ae039.font(Cam.toGuiScale(35))}`,
		ctx.strokeText(cs, canvas.width / 2, Cam.toGuiScale(40)),
		ctx.fillText(cs, canvas.width / 2, Cam.toGuiScale(40)),
		ctx.font = `bold ${$f36928166e04fda7$export$2e2bcd8739ae039.font(Cam.toGuiScale(25))}`,
		ctx.strokeText(`# of zones: ${area.zones.length}`, canvas.width / 2, Cam.toGuiScale(75)),
		ctx.fillText(`# of zones: ${area.zones.length}`, canvas.width / 2, Cam.toGuiScale(75)),
		ctx.strokeText(`# of assets: ${area.assets.length}`, canvas.width / 2, Cam.toGuiScale(100)),
		ctx.fillText(`# of assets: ${area.assets.length}`, canvas.width / 2, Cam.toGuiScale(100)),
		ctx.strokeText(`# of entities: ${area.entities.length+plrs.length}`, canvas.width / 2, Cam.toGuiScale(125)),
		ctx.fillText(`# of entities: ${area.entities.length+plrs.length}`, canvas.width / 2, Cam.toGuiScale(125));
	}
	ctx.strokeStyle = "#000";
	ctx.lineWidth = Cam.toGuiScale(4);
	ctx.font = `bold ${$f36928166e04fda7$export$2e2bcd8739ae039.font(Cam.toGuiScale(15))}`;
	ctx.textBaseline = "middle";
	ctx.textAlign = "right";
	ctx.fillStyle="white";
	if(isPrivateBuild)version[0]=version[1]=version[3]="",version[2]=". Real convincing sign, huh?";
	ctx.strokeText(`${isPrivateBuild ? "" : "Evades Region Editor "}${version[3]}${version[0]}.${version[1]}.${version[2]}`,canvas.width-Cam.toGuiScale(10),canvas.height-Cam.toGuiScale(95)+canvasBox.hidden*Cam.toGuiScale(80)),
	ctx.fillText(`${isPrivateBuild ? "" : "Evades Region Editor "}${version[3]}${version[0]}.${version[1]}.${version[2]}`,canvas.width-Cam.toGuiScale(10),canvas.height-Cam.toGuiScale(95)+canvasBox.hidden*Cam.toGuiScale(80))
	ctx.textAlign = "left";
	if (!playtesting)
		alertMessages=alertMessages.filter(e=>e.removeAfter>lastTime),
		alertMessages.map( (e, t, a) => {
			ctx.fillStyle = "function" === typeof e.color ? e.color(lastTime-e.removeAfter+e.duration*1e3) : e.color;
			ctx.strokeText(`${e.text}`, Cam.toGuiScale(10), canvas.height - Cam.toGuiScale(20) * (1+a.length - t), canvas.width - Cam.toGuiScale(20));
			ctx.fillText(`${e.text}`, Cam.toGuiScale(10), canvas.height - Cam.toGuiScale(20) * (1+a.length - t), canvas.width - Cam.toGuiScale(20));
		});
	ctx.lineJoin = "miter";
	ctx.textBaseline = "alphabetic";
	let v = `hsl(${lastTime/1e3*180}deg,100%,50%)`;
	ctx.strokeStyle = ctx.fillStyle = v,
	ctx.lineWidth=Cam.toGuiScale(2);
	ctx.beginPath();
	const mp = {x:canvas.width / 2 + mousePos.ex,y:canvas.height / 2 + mousePos.ey};
	if(playtesting && (!$e7009c797811e935$export$2e2bcd8739ae039.allowButtonPropagation && settings.enableMouseMovement) || (settings.toggleMouseMovement && $e7009c797811e935$export$2e2bcd8739ae039.mouseMovementToggled)){
		ctx.moveTo(mp.x,mp.y-Cam.toGuiScale(12));
		ctx.lineTo(mp.x,mp.y+Cam.toGuiScale(12));
		ctx.moveTo(mp.x-Cam.toGuiScale(12),mp.y);
		ctx.lineTo(mp.x+Cam.toGuiScale(12),mp.y);
	}else if(-1 !== "du".indexOf(selectMode)){
		ctx.moveTo(mp.x-Cam.toGuiScale(12),mp.y);
		ctx.lineTo(mp.x+Cam.toGuiScale(12),mp.y);
		arrow(ctx,mp.x,mp.y,mp.x,mp.y+Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x,mp.y-Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v);
	}else if(String(selectMode).startsWith("o")){
		let ang = Math.PI/2 * "rdlu".indexOf(selectMode.slice(1));
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16)*Math.cos(ang),mp.y+Cam.toGuiScale(16)*Math.sin(ang),Cam.toGuiScale(16),1,"#000",v);
	}else if(-1 !== "lr".indexOf(selectMode)){
		ctx.moveTo(mp.x,mp.y-Cam.toGuiScale(12));
		ctx.lineTo(mp.x,mp.y+Cam.toGuiScale(12));
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v);
	}else if(-1 !== "ul,dr".split(",").indexOf(selectMode)){
		let u = 1 / Math.sqrt(2);
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16)*u,mp.y-Cam.toGuiScale(16)*u,Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16)*u,mp.y+Cam.toGuiScale(16)*u,Cam.toGuiScale(16),1,"#000",v);
	}else if(-1 !== "ur,dl".split(",").indexOf(selectMode)){
		let u = 1 / Math.sqrt(2)
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16)*u,mp.y+Cam.toGuiScale(16)*u,Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16)*u,mp.y-Cam.toGuiScale(16)*u,Cam.toGuiScale(16),1,"#000",v);
	}else if("m" === selectMode){
		arrow(ctx,mp.x,mp.y,mp.x,mp.y+Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x,mp.y-Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v);
	}else if(selectMode === "x"){
		let u = 1 / Math.sqrt(2);
		ctx.moveTo(mp.x-Cam.toGuiScale(16)*u,mp.y-Cam.toGuiScale(16)*u);
		ctx.lineTo(mp.x+Cam.toGuiScale(16)*u,mp.y+Cam.toGuiScale(16)*u);
		ctx.moveTo(mp.x+Cam.toGuiScale(16),mp.y);
		ctx.arc(mp.x,mp.y,Cam.toGuiScale(16),0,Math.PI*2,false);
	}else if(selectMode === "p"){
		let a = [Math.cos(Math.PI*2/3),Math.sin(Math.PI*2/3)];
		ctx.moveTo(mp.x+Cam.toGuiScale(16),mp.y);
		ctx.lineTo(mp.x+Cam.toGuiScale(16)*a[0],mp.y+Cam.toGuiScale(16)*a[1]);
		ctx.lineTo(mp.x+Cam.toGuiScale(16)*a[0],mp.y-Cam.toGuiScale(16)*a[1]);
	}else if(null === selectMode){
		let u = 1 / Math.sqrt(2);
		arrow(ctx,mp.x+Cam.toGuiScale(16)*u,mp.y+Cam.toGuiScale(16)*u,mp.x,mp.y,Cam.toGuiScale(16),1,"#000",v);
	}else if(-1 !== "vh".indexOf(selectMode.slice(1))){
		selectMode.indexOf("v")!=-1&&(
		arrow(ctx,mp.x,mp.y,mp.x,mp.y+Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v),
		arrow(ctx,mp.x,mp.y,mp.x,mp.y-Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v));
		selectMode.indexOf("h")!=-1&&(
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v),
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v));
	}
	ctx.closePath();
	ctx.fillStyle="black";
	ctx.stroke();
	"x" !== selectMode && ctx.fill();
};

const assetsLoaded={count:0};
// font loader
!function(){const e=new FontFace("EvadesArial",'url("fonts/arial-bold.evades.woff2")',{weight:"bold"}),a=new FontFace("EvadesTahoma",'url("fonts/tahoma-regular.evades.woff2")'),t=new FontFace("EvadesTahoma",'url("fonts/tahoma-bold.evades.woff2")',{weight:"bold"}),c=new FontFace("fnt_barrio",'url("external/fnt_barrio.woff2")'),r=new FontFace("fnt_my_home",'url("external/fnt_my_home.woff2")');[e,a,t,r,c].map(o=>o.load().then(f=>(assetsLoaded.count++,document.fonts.add(f),animate(render))))}();
function getAbilityIndex(name){return EvadesConfig.abilities.findIndex(e=>e.name==name)}
function getEffectIndex(name){return EvadesConfig.effects.findIndex(e=>e.name==name)}
const loadImage = function(src){
  if(typeof src!="string")return;
  if(src.endsWith(".mp4")){
    let vid=document.createElement("video");
    vid.src=src;
    vid.onerror = () => {
      console.log("Unable to load video",src);
    }
    vid.oncanplaythrough = () => {
      assetsLoaded.count++;
	  vid.oncanplaythrough=null;
    }
    return vid;
  }
  if(src.endsWith(".mp3")||src.endsWith(".ogg")){
    let aud=new Audio();
    aud.src=src;
    aud.onerror = () => {
      console.log("Unable to load audio",src);
    }
    aud.oncanplaythrough = () => {
      assetsLoaded.count++;
	  aud.oncanplaythrough=null;
    }
    return aud;
  }
  let image = new Image();
  image.src = src;
  image.onerror = () => {
    console.log("ERROR AT", image.src);
  }
  image.onload = () => {
    assetsLoaded.count++;
	image.onload=null;
  }
  return image;
}
isActive=true;
settings.local.activatedExtensions??="";
const activated_extensions=settings.local.activatedExtensions.split(",");
if(activated_extensions.indexOf("")!=-1)activated_extensions.splice(activated_extensions.indexOf(""),1)
activated_extensions.map(e=>{
	document.getElementById(e).checked=true;
})
var usingFPE=activated_extensions.indexOf("rotatedWallAssets")!=-1;
var usingAutomationTools=activated_extensions.indexOf("automationTools")!=-1;
//usingVanillaEnemySet should be set to false when a custom enemy type (from a sandbox, not in evades.io) is added.
//causes the addon enemy properties folder to show up (even if there are no properties in the folder, but its probably fine)
var usingVanillaEnemySet = !usingFPE;
global.addEventListener("blur",function () {
  isActive = false;
})
global.addEventListener("focus",function () {
  isActive = true;
})
function Base64_To_Ascii(str) {
  return str.replace(/=/g, "").split("").map(e => {
    var char = 0;
    if (e.charCodeAt(0) > 64 && e.charCodeAt(0) < 96) char = e.charCodeAt(0) - 65;
    if (e.charCodeAt(0) > 96) char = e.charCodeAt(0) - 71;
    if (e.charCodeAt(0) < 64) char = e.charCodeAt(0) + 4;
    if ("+" == e) char = 62;
    if ("/" == e) char = 63;
    char = char.toString(2);
    return `${"0".repeat(6 - char.length)}${char}`
  }).join("").match(/(........)/g).map(e => { return String.fromCharCode(parseInt(e, 2)) }).join("")
}
function AsciiToBase64(str){
    var map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".split("");
    var t = str.split("").map(e=>e.charCodeAt());
    var res=[];
    if(t.filter(e=>(e>255)).length)throw"Unicode character is outside of Latin range (0 - FF)";
    for(var i=0;i<t.length;i+=3){
        res.push(t[i]>>2&0b111111);
        res.push((t[i]<<4&0b110000)+(t[i+1]>>4&0b1111));
        (t[i+1]!=void 0)&&res.push((t[i+1]<<2&0b111100)+(t[i+2]>>6&0b11));
        (t[i+2]!=void 0)&&res.push(t[i+2]&0b111111);
    }
	res=res.map(e=>map[e]);
	while(res.length%4!=0)res.push("=");
    return res.join("");
}