## The Abyssal Update (β1.3) - 08-08-25
*	Sour Candy Effect will deactivate when you leave the area.
*	Implemented Superstar enemy.
*	Cat Onesie will now render with colors of the hero.
*	Fixed username setting not saving after server shutdown.
*	Added Minimap Entity Scale setting. (Default: 0.5)
*	Implemented all AA enemies straight lifted from Pifary-dev/ravel.
*	Updated the list of cosmetics. (see in Play Mode section)
*	Effect Blending and Enemies On Minimap settings are now added.
*	Fixed a bug where projectile outlines were 2x thicker than the official render.
*	Implemented Withering and Void Drain enemies.
*	Fundamental Paper Entities<br><br>More teachers have been added. (except that they are passive)

## Nobody will let me see the EvadesClassic entity source code (β1.2.2) - 08-04-25
*	Sorry but i won't add any of ancient abyss related enemies.
*	Frame rate setting is now readded. (Default: 60)
*	Fundamental Paper Entities<br><br>Fixed a bug where Science wouldn't roll another random chance after interrupted by attack playback.

## β1.2.1 - 07-02-25
*	Addon Experiemental: Rotated Walls that was previously removed is now readded and replaced by Fundamental Paper Entities.

## β1.2 - 06-30-25
*	Stellar Square<br><br>You will now respawn instead of removing.<br>Not being in active zone will reset your stats.

## β1.1.7 - 06-29-25
*	Fixed a bug where after importing a region (legacy version), enemy stats inside summoner enemy's spawner will get reduced by 30×.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/37#:~:text=For%20the%20spawner%20property%20of%20summoner%20enemies%2C%20the%20enemies%20stats%20in%20the%20spawner%20will%20be%20much%20lower%20for%20every%20import%20of%20a%20map">#37.4</a></sup>
*	Player speed can now be clamped by maximum and minimum speed props.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/37#:~:text=the%20maximum%20speed%20property%20in%20the%20active%20areas%20will%20do%20nothing.">#37.3</a></sup>
*	Areas with magnetism properties will now give Magnetism ability.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/37#:~:text=activating%20magnetism%20does%20not%20give%20magnet">#37.2</a></sup>
*	Fixed rendering issues with gigantic zones.

## Hotfix (β1.1.6) - 06-25-25
*	Fixed a performance issue where Plbot Enemy wouldn't simulate correctly and spawns way too many entities.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/37#:~:text=plbot%20does%20not%20simulate%20correctly%2C%20and%20summons%20so%20many%20enemies%20it%20crashes%20the%20browser">#37.1</a></sup>

## β1.1.5 - 06-19-25
*	Added `interfaceScale` to settings.
*	Canvas aspect ratio is now locked to 16:9 again.

## β1.1.4 - 06-17-25
*	Fixed a bug where Snow/Sakura wouldn't render properly.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/35">#35</a></sup>

## β1.1.3 - 06-03-25
*	Fixed a bug where Tree Enemies wouldn't spawn in Haunted Halls Deep Woods if angle is an array.
*	Fixed a bug where you would see artifacts while using no tiles.

## β1.1.2 - 06-01-25
*	Fixed a bug where BOSS AREA flag would persist after leaving the boss area in playtesting mode.

## β1.1.1 - 05-31-25
*	Removed transparency bars for WB_TestQuestions overlay.
*	Cursors will now properly scale to the GUI.

## β1.1 - 05-30-25
*	Removed transparency bars.
*	Fixed a bug where world.yaml wouldn't be loaded offline or in local file system.
*	Fixed a bug where Stellar Square Hard wouldn't be loaded offline or in local file system after interacting Key Enemy in Stellar Square.

## β1.0.6 - 05-23-25
*	Entity variations are added at the end of Infinite Inferno Area 15.<br>Updated area text in Infinite Inferno Area 15.
*	The number of entities will now count players in the current area.

## How does this quiz thing work? (β1.0.5.<a href="https://www.youtube.com/@Aphmau?sub_confirmation=1">#</a>) - 05-20-25
*	<a href="https://aphmeow.com/quiz" draggable="false" style="width:160px;height:160px;background-blend-mode:multiply;background-color:currentColor;background-image:url(https://cdn.shopify.com/s/files/1/0678/8926/6969/files/AphmauCollection_BottomBanner-Mobile.gif);background-size:cover;display:block;"></a>(NOT MINE)

## β1.0.5_01 - 05-15-25
*	Fixed context menu background color not being applied in Light Theme.

## β1.0.5 - 05-11-25
*	Fixed a bug where zooming in/out wouldn't center on mouse position correctly. (Editor Mode)

## β1.0.4 - 05-10-25
*	Fixed a bug where DeathTimerDirectionalIndicator entities would incorrectly point to where the player was.
*	Fixed a bug where if another player offscreen is downed, HeroInfoCard entity and Toggle Minimap Mode button will be rendered wrongly.
*	Duplicate Area<br><br>Added another button similar to that action but it inserts at your area index. (Suggested by `@utterrivver`)

## β1.0.1 - 05-09-25
*	Added a hotkey to hide UI elements in Playtesting Mode: U

## 100% Enemy Simulation - 05-04-25
*	The Region Editor now enters the beta stage! (β1.0.0)
*	Implemented Electrical Enemy Projectile.
*	Fixed a bug where you would get killed when you contact barrier enemy's aura and touch active zone at the same time. (It was affected in CC<sub>2</sub>(H) and Research Lab's Facility Area)
*	Barrier effect in Barrier Dome is no longer affected by Blocking Enemy.

## α1.25.8 - 05-03-25
*	Stream Path will now prevent players from being slowed down by enemies.

## α1.25.7 - 04-23-25
*	R key is no longer bounded to max out hero card stats and was replaced by commands /max and /m.
*	U key is no longer bounded to revive yourself and was replaced by commands /revive, /rv, /save, and /s. 2 weeks later, this key got rebounded as toggling UI elements.

## α1.25.6 - 04-16-25
*	Fixed a bug where Sour Candy Items were culled incorrectly whilst using affine transformation.

## α1.25.5 - 04-15-25
*	Fixed a bug where Sour Candy Items would never render at all.
*	Fixed a bug where Summoner's spawner was not specified, causing an error when trying to export or duplicate zones.
*	Area text in each region has been significantly updated.
*	Switch Station is now available in the region selection.

## α1.25.4 - 04-14-25
*	You can now select an existing player entity to playtest after ejected into editor mode. The cursor becomes triangle when you hover on a player in editor mode.

## α1.25.3 - 04-13-25
*	Translate arrows now have colored borders instead of plain black border.

## α1.25.2 - 04-12-25
*	Cybot's Robo Scanner Entities<br><br>Implemented Sniper, Ice Sniper, Speed Sniper, Regen Sniper, Prediction Sniper, and Lead Sniper projectiles.

## α1.25.1 - 04-11-25
*	Added `displayGameplayHints` to settings.
*	Nexus has been implemented along with Aurora.

## α1.25.0 - 04-10-25
*	Character limit in chat is increased from 160 to 32000.
*	Added colon emoji syntax support in chat.
*	Fixed a bug where dasher enemies weren't behaving properly upon being spawned by spawner.

## Announcement - 04-08-25
*	**However, due to their organization admin blocked this website and Evades.io, we're sorry, you have to wait for the summer to come. 😅**<br>The rest of you will continue editing as usual.
*	Incident <a style="color:#DC352C" href="https://status.glitch.com/incidents/gb79r0mw51ml" target="_blank">Network Degradation</a> was currently active and affected Project Hosting, Editor, and API.<br>This incident liked to stop me from importing official regions or accessing the editor.

## α1.24.7 - 04-07-25
*	Custom cursors now have a rainbow stroke and black color.

## α1.24.6 - 04-06-25
*	Database will now use 64-bit integers for IPv6 instead of using UUID format.

## Technical Difficulties (α1.24.5) - 04-05-25
*	Area loading has been reworked.<small>If the player is in the loaded area while playtesting, it will not reset the area. Also if you are in editor mode, players will be teleported to the first available safe zone when modifying the area.</small>

## EvadesClassic reverted changes. (α1.24.4) - 04-04-25
*	The Mysterious Event™ has been successfully deleted from the existence.
*	Added a new entity at the end of Infinite Inferno. (This is where it has a YouTube link as area text)
*	Fixed a bug where Harden, Flow, and Paralyze (aura) effects wouldn't get removed properly after contacting disabling enemy aura.
*	Removed Stellar Square Hard from region selection list.<small>To access this region, place a key enemy in stellar square and playtest it.</small>
*	Changes after Seecret April Fools Update 2 are reverted and replaced by another mysterious change involving commands.

## α1.24.3_02 - 04-03-25
*	~~The new challenger will try to forcibly open the specified fandom wiki page once when you die to it.~~<small>This change has been reverted and removed.</small>

## Seecret April Fools Update 2 (α1.24.3_01) - 04-02-25
*	<img src="https://cdn.glitch.me/ecf340e9-15c3-4a37-b00f-34e251e5d225/NewChallenger.webp" alt="A new challenger has appeared !" style="image-rendering:pixelated;width:100%">
## α1.24.3 - 04-01-25
*	Added a check for when a player is out of bounds.<br><small>They get teleported inside the area at the first available safe zone when it is out of bounds.</small>
*	Corrected movement behavior for Dorito and Dorito Switch enemies.
*	Implemented Randomizing, Snow Sniper, Snow Liquid, and Key Enemies.
## α1.24.2 - 03-31-25
*	Mutating Enemy<br><br>Mutating enemy will now properly update pellet colors depending on the theme. (e.g. dark or light)<br>Fixed a bug where pellet oscillator is 30× slower than intended.

## α1.24.1 - 03-28-25
*	Invulnerable icon is now based on tiers:<br>Tier 1 - vulnerable to corrosive entities<br>Tier 2 - immune to all entities<br>Tier 3 - immune to all entities and effects

## α1.24.0 - 03-27-25
*	All other UI elements are now moved inside 1280x720 scalable box.
*	Enabling god mode will now remove all active negative status effects from your character.
*	Fixed a bug where quicksand effect would ignore blocking effect check.
*	Mutating Enemy's deactivation range is now 1000 instead of Infinite.

## α1.23.3 - 03-25-25
*	Playtesting will now disable actions instead of hiding itself at top left.
*	Play button can now be animated between 2 icons as transition and moved to top-left corner.
*	The list of gems/cosmetics has been updated.

## α1.23.2 - 03-24-25
*	Settings<br><br>Sections are now tabs instead of displaying all sections.<br>Added play button to replace "PLAYTESTING" header.
*	Enabling god mode will now protect you from enemy debuffs.

## Is this enemy simulation 100% complete? (α1.23.1) - 03-23-25
*	Unfortunately, there is Electrical Enemy Projectile still unimplemented.
*	Elbot, Dabot, Libot projectiles and Thunderbolt Enemy are now implemented.

## α1.23.0 - 03-22-25
*	CC2H minibosses will no longer cause softlock when attempting to spawn unimplemented entities.
*	A setting for adjusting frame rate has been removed because of incorrect behavior of restoring stats other than 60 FPS.
*	Fixed a bug where oscillating enemy reduced effects wouldn't register properly.
*	Dorito, Dorito Switch, Sparking, Summoner, Electrical, and Wacky Wall Enemies are now implemented.

## α1.22.6 - 03-21-25
*	Mutating Enemy is now implemented.
*	Fixed a bug where oscillating enemies that collided turned 180 degrees instead of bouncing.
*	Because of that, Experiemental: Rotated Walls is removed from addons.

## *The Day of The Equinox* (α1.22.5) - 03-20-25
*	Penny, Penny Switch, and Lotus Flower enemies are implemented. (Shout out to `@amasterclasher` for Penny Enemy movement)
*	Title Stroke Color can now be customized in area and region properties.

## α1.22.4 - 03-19-25
*	Fixed some internal issues with IPv6 being incorrectly parsed as IPv4.
*	Users that are affected by that bug and using IPv6 connections are erased from the database.

## α1.22.3 - 03-18-25
*	Growth Multiplier is no longer capped at 1.
*	Fixed a bug where pressing CTRL+A would select objects more than 1 time when it was not supposed to.
*	You can now rotate the entire area that are all selected.

## <font style="color:#3b5;font-weight:bold;">Happy Saint Patrick's Day!</font> (α1.22.2) - 03-17-25
*	Fixed a bug where Stalactite enemies were not immune comparing to the official game.
*	Creating an area will now use Avoids.io default area template instead of blank template (no zones in area).

## α1.22.1 - 03-14-25
*	Fixed a bug where attempting to play as Ordinary would crash the entire editor because hero abilities array is not defined.
*	Fixed a bug where selected objects' stroke color was black instead of red if there is translate arrow in the first index.
*	Renamed spawner property `switched_harmless` to `randomize_state`.
*	Functionality of creating spawner properties is now implemented.

## Minor Changes IV (α1.22.0) - 03-12-25
*	Remember when it says about <a href="#AFU1">The Mysterious Event™</a>? This turns out that it is Seecret April Fools Update 1 that occurs annually.
*	Fonts in TTF format are now converted into WOFF2 format.
*	Chat throttling has been added.
*	Chat history will now handle up to 10000 messages.
*	Simulation will no longer crash the entire editor. Instead, the entity that tried to crash the simulator will freeze itself with "NOT SIMULATING." below it.
*	Slasher Enemy<br><br>Slasher enemy now has a fading effect when slash timer is almost 0.
*	Added `enemyProjectileOutlines` setting.
*	Fixed a bug where confetti would disappear after 1 frame.
*	Fixed a bug where black bars would get canvas tainted by cross origin data. (The same image that was used for the video when it says "consumed.")
*	Added a visual effect for enemies that are being frozen by Rime.
*	Fixed a bug where Teleporting and Star enemies would still move after being frozen by Rime.

## α1.21.6 - 03-11-25
*	Seedling Projectile<br><br>Seedling projectiles will now collide walls.
*	Implemented Ninja Star Sniper Enemy.
*	Fixed a bug where cent mouse movement was clamped incorrectly at 1 instead of 150.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/31">#31</a></sup>
*	Tree Enemy<br><br>If tree enemies are unable move, they can't shoot leaf projectiles.
*	Star Enemy<br><br>Star enemies no longer bounce off walls.
*	Teleporting Enemy<br><br>The frequency of teleporting enemies' warp now scales with their speed.
*	Fixed a bug where immune spawner property wouldn't update the status of the immune effect for enemies.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/30">#30B</a></sup>
*	Fixed a bug where game camera position is NaN while loading.

## α1.21.5 - 03-10-25
*	Fixed a bug where reducing effect could still kill a player who was in god mode. (N key, Evades.io Command: /g)

## α1.21.4 - 03-09-25
*	Implemented Slasher enemy.

## α1.21.3 - 03-08-25
*	Fixed a bug where effect_radius property won't be copied from the spawner when cloning it or exporting a region.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/30">#30A</a></sup>

## α1.21.2 - 03-07-25
*	Implemented Infinity, Infinity Switch, and Blind enemies.
*	When you resize zones with last_x, last_right, last_y, or last_bottom, it will no longer change X/Y position until mouse is released.
*	Cursors has been changed significantly.

## α1.21.1 - 03-06-25
*	Fixed a bug where duplicating/copy-pasting/cut-pasting assets wouldn't copy width and height.
*	Fixed a bug where enemies that are not implemented would be rendered below flashlight item entity.
*	Experiemental: Rotated Walls<br><br>Rotation speed has been added. (default: 0)
*	Fixed a bug where drawn images that are horizontally flipped are culled incorrectly when touching the edge of the game camera.

## New Command! (α1.21.0) - 03-05-25
*	Fixed a bug where importing a legacy region file (e.g. `first-map.legacy (1).yaml`) wouldn't trigger legacy flag correctly.
*	Added /goto command. This command teleports you to the specified area. (Teleporting to the same area you are in will not count)

## α1.20.16 - 02-15-25
*	Legacy 30 FPS was renamed and reworked into an adjustable frame rate.

## α1.20.15 - 01-10-25
*	Fixed a bug where Automation Tools wasn't working properly.
*	Fixed a bug where X, Y, and Angle would sometimes cause NaN when spawned

## α1.20.14 - 01-03-25
*	Fixed a bug where Game Camera's zoom was stuck at the constant number at which is when used for playtesting while editing.
*	Because of the strict 2FA in Github, the account (Sonic3XE) associated by sonic.exe666 (Discord) became inaccessible and possibly terminated the access until 2FA is properly enabled.

## 12-25-24
*	Github<br><br>Github Edition of Evades Region Editor is no longer supported. Please migrate to <a href="https://evades-regedit-2025.glitch.me/">https://evades-regedit-2025.glitch.me/</a>

## α1.20.13 - 12-17-24
*	Fixed incorrect HUD layering order.

## α1.20.12 - 12-16-24
*	Fixed a bug where pressing U while dead as Necro with resurrection available could persist until resurrection ability is used.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/21">#21</a></sup>

## α1.20.11 - 12-12-24
*	Implemented Particle Generator entity.
*	Fixed a bug where you can select objects while on the black bar.
*	Zones will no longer render itself when offscreen.
*	Fixed icon positioning. (Thanks to `@.exobyte.` for pointing out this misalignment)

## α1.20.10 - 12-08-24
*	Confirmation overlay now blurs out the main GUI.

## 12-04-24
*	The region editor has been restored.

## Happy Halloween! You had watched an evades horror video. - 10-31-24
*	The region editor has been corrupted.

## I should've (α1.20.9) - 10-26-24
*	Fixed a bug where lunging enemies would be teleported to NaN positions after collision.<br><small>HalReturns, please stop messaging in chat about bugs or issues, you can report that to <a href="https://github.com/sonic3XE/evades-region-editor/issues/new/choose">my github repo.</a> (in which if you don't have a github account, you can still register an account)</small>

## α1.20.8 - 10-23-24
*	Fixed a bug where after cycling to an enemy for a first time, the collisions weren't applied properly.

## α1.20.7 - 10-20-24
*	Fixed a bug where flipped torch textures weren't rendering on screen.
*	Fixed a bug where the small blank box can still be selected (visually shown as white outline) after selecting a specified region.
*	Fixed a bug where homing enemy's target angle didn't change upon collision.
*	N key - Toggles godmode

## α1.20.6 - 10-19-24
*	Implemented Morfe.
*	Fixed a bug where minimum speed weren't applied on top of each other.
*	Some abilities were not implemented, it would probably end up being deleted or hidden away.
*	Crashes on Crumbling enemy trying to restore to original stats are now lifted<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/18">#18</a></sup> since I found the formula (Thanks to <a href="https://www.desmos.com/calculator">Desmos</a> for that).
*	Ordinary<br><br>Unlike other heroes, this hero have no abilities. The only exception is the 3rd ability.

## α1.20.5 - 10-17-24
*	Experimental Feature: Rotated Walls (Available in Addons)<br><br>Wall assets can now be rotated by an angle property in degrees. (Default: 0)
*	Fixed a bug where stalactite_enemy_projectile wouldn't spawn when stalactite enemy collided a wall.

## α1.20.4 - 10-15-24
*	Fixed a bug where pellets wouldn't spawn in small areas after first zone being biggest.

## α1.20.3 - 10-11-24
*	Fixed a bug where font sizes in each action text weren't applied correctly.

## α1.20.2 - 10-09-24
*	Fixed a bug where entities can escape their own boundary if the radius is 0.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/17">#17</a></sup>

## α1.20.1 - 10-07-24
*	Cybot Phase 3<br><br>Implemented Cybot Ring Projectile<br>This will no longer crash.
*	Fixed a bug where static enemies would disappear when you touch it.
*	Fixed a bug where you could immediately move after pressing U while inside an enemy.
*	Fixed a bug where boundary wall's Y position is not positioned correctly.

## α1.20.0 - 10-06-24
*	Necro is now implemented.
*	Implemented Infectious Enemy<br>Note: When you touch that enemy, your revival abilities will get disabled until you are revived.

## α1.19.4 - 10-05-24
*	Fixed a bug where if you try to playtest but it spawned you outside of an area, it will cause NaN position.
*	Fixed a bug where player entities who are already moved won't stop moving after selfId was changed.
*	You can now playtest the map by going to settings and clicking/tapping on the "PLAYTESTING" text if there is no F4 key on the keyboard.

## α1.19.3 - 10-04-24
*	Entity rendering order has been updated.
*	Boundary walls are now added. (2000px thickness)
*	Unknown enemies will no longer crash upon being spawned by spawner.
*	Debug<br>Blue outline has been added to the area to determine void outside of that outline.
*	Fixed a bug where pumpkin enemies weren't rendered in camera due to FOV Scaling.
*	Fixed a bug where if your death timer runs out or touching removal zone or the playtesting feature didn't find the specified player with the exact self id, the top-left GUI element won't reappear.

## α1.19.2 - 09-27-24
*	Lava Enemy's aura now has a following effect: When the player's energy is full, the player will be slowed by 95% for 1.5s of burning time. Otherwise, players will gain 8 energy per second.

## α1.19.1 - 09-26-24
*	Fixed a bug where the player radius when not interacting reducing aura still increases, causing some player sizes to inflate.
*	Minimum speed on players are no longer capped below 0.
*	Fixed a bug where using 3rd ability caused a crash when the ability is non-existent.
*	Common gamepad/controller is now supported in playtesting mode only.
*	Fixed a bug where keys property in gameState object doesn't exist.
*	Fixed a bug where an object can be selected twice.
*	Fixed null object issue when releasing a mouse button.

## α1.19.0 - 09-25-24
*	As of **The Slick Sixty Update** in Evades, `push_direction` is now removed from spawner properties.
*	Fixed a bug where homing enemies aren't precisely homing in players or mouse position correctly.
*	Fixed a bug where attempting to apply fibot debuff caused a crash.
*	Flag `player.cannot_leave_area` is now implemented. (This flag behaves so that you can't leave the current area until that flag is off.)
*	Fixed a bug where prediction snipers weren't shooting when the player velocity is not using legacy units.

## α1.18.6 - 09-24-24
*	Visual Fix: Fixed folder "Sniper Enemy" being missing from the spawner.
*	Fixed a bug where background_color values are not limited between 0 and 255.
*	Fixed a bug where setting to a value of which isn't an integer in background_color caused a crash.

## α1.18.5 - 09-23-24
*	English gets loaded immediately after DOM.
*	You can now select multiple objects in the object selection area.

## α1.18.4 - 09-17-24
*	You can now gain experience once a player discovered a new area.

## α1.18.3 - 09-16-24
*	Reverted changes to tile rendering due to stuttering effects when moving a player.
*	Updated HUD renderer.
*	Fixed some performance issues with interactable buttons.

## Mentioned by EvadesClassic commit (α1.18.2) - 09-15-24
*	<a href="https://github.com/amasterclasher">amasterclasher</a> authored a commit: Changelog typo, thanks <a href="https://github.com/sonic3XE/" style="color:#FFF !important">sonic</a>
*	Fixed a bug where Reducing auras weren't reducing player's radius.
*	Fixed a bug where the player can move for 1 frame before giving iced effect by Ice Ghost enemies.
*	Fixed a bug where the flow effect didn't apply correctly.

## α1.18.1 - 09-11-24
*	Implemented Aurora's Distort.

## α1.18.0 - 09-10-24
*	Export<br><br>When you export a file with legacy speed units setting on, the file name will include .legacy as a legacy flag.
*	Import<br><br>When you import a file with legacy flag (e.g. <i>`central-core.legacy.yaml`</i>) the editor will convert to non-legacy values.
*	Property `all_enemies_immune` now applies to enemies that are spawned by spawner.

## α1.17.5 - 09-09-24
*	Abilities from the client hero card are now integrated to player class to prevent crashing when a player touches force sniper projectile.
*	Fixed a bug where using harden while being lead still maintains movement velocity instead of stopping.

## α1.17.4 - 09-07-24
*	Fixed a bug where creating an object gets positioned incorrectly when using other than <a href="https://www.google.com/chrome/">Google Chrome</a>.
*	Fixed a bug where some enemies can actually leave their own boundaries.

## α1.17.3 - 09-06-24
*	<a href="https://docs.google.com/">Google Docs</a> did the job for translations.<br>Russian language has been added.<br>Thanks to **Гость с Марса** for translating enemies.

## α1.17.2 - 09-05-24
*	Fixed a bug where duplicating an area caused conversion to a legacy version of an area.
*	The confirmation popup is now different than before.<br>Confirmation overlay has been added.

## α1.17.1 - Minor Changes III - 09-03-24
*	Fixed a bug where Iced effect was applied incorrectly, allowing you to move normally as if never happened.
*	Wall assets are now shown in minimap if its texture is visible.
*	Fixed a bug where null texture throws an error.
*	Export<br><br>Area and zone properties no longer apply default values.
*	Properties have been changed to how Evades.io behaves:<br>Existing zone properties now override area properties.<br>Existing area properties now override region properties.

## α1.17.0 - Minor Changes II - 09-02-24
*	Fixed some freezes whenever the chat message has been received from the server.
*	Fixed some texture issues in HUD while playtesting.
*	Export<br><br>When you have legacySpeedUnits setting on, you can export the map with legacy units and will be compatible to any existing evades.io sandbox.
*	Happy Labor Day! I made some fixes to texture rendering like abilities and minimap mode button. Accessories that have reversed texture can be reversed depending on the input angle.

## α1.16.3 - 09-01-24
*	Simulator has been returned due to enemy implementations.<br>Implemented Cybot, Dabot, Libot, Aibot, Wabot, Fibot, Eabot, Plbot, Mebot, Elbot, Icbot enemies.

## α1.16.2 - 08-26-24
*	Bring back asset entities.

## α1.16.1 - 08-25-24
*	Added requirement string: `switch_station_found`

## α1.16.0 - 08-24-24
*	Now using texture atlas from Evades.io
*	Selecting an object outside of 16:9 aspect ratio will no longer register.

## Simulator has discontinued (α1.15.10) - 08-20-24
*	Fixed a bug where pressing enter to highlight the chat box stopped working properly.
*	GUI chat and leaderboard are now visible without playtesting, however though, it is under the editing layer.
*	Simulator has been shut down due to lack of verification of entity PY files.

## α1.15.9 - 08-19-24
*	Disabled playtesting mode as it was about to shut down the simulator in August 20, 2024 at 06:00 CDT.
*	I told y'all about that exact timestamp.

## α1.15.8 - 08-17-24
*	Implemented Confectioner and Confectioner Switch enemies.

## α1.15.7 - 08-16-24
*	Display Legacy Speed Units setting will now properly sync with spawner properties.

## α1.15.6 - 08-14-24
*	Fixed a bug where if you pick up the flashlight, the simulator will crash.
*	Fixed a bug where players are rendered under assets and/or any entities.

## α1.15.5 - 08-10-24
*	Implemented ability Lantern.

## α1.15.4 - 08-09-24
*	Implemented ability Snowball.

## α1.15.3 - 08-08-24
*	Changed sandbox flag to Legacy 30FPS.
*	Fixed a bug where dead players can get affected by speed and regen sniper projectiles that are not supposed to.
*	Fixed a bug where players that got snowballed, iced or poisoned don't render over the character.
*	Fixed a bug where frost giant enemies turn acceleration are 30x slower than expected.
*	Fixed a bug where turning enemies turn 30x faster than expected.
*	Fixed a bug where if you haven't rewarded accessories and it tries to render, the renderer will crash on its own.
*	Fixed a bug where leaving a victory area that contains a removal will remove you from the simulation instead.

## α1.15.2 - 08-07-24
*	Mouse Input Indicator has been added to playtesting mode only.
*	Fixed a bug where magnetism and partial_magnetism forces you vertical 300 pixels per frame instead of 300 pixels per second.
*	Fixed a bug where speed in the ability description is untranslated.

## α1.15.1 - 08-05-24
*	Fixed updateMap function being in the wrong area order.
*	Added fadingEffects, displayEnergyBars, pelletTransparency to settings.
*	Added switched_harmless spawner property.

## α1.15.0 - 08-04-24
*	Areas that are boss areas are now completely rendered.
*	Added legacySpeedUnits to settings.
*	Added more properties. `slow`, `drain`, `home_range`, `increment`, `recharge`, `spawns_lost_souls`.<br>Removed `lightning_reduced`
*	Requirement strings<br><br>Removed `all_elements_gained`.<br><br>Added `icbot_not_defeated`, `cybot_hard_mode_not_defeated`, `elbot_not_defeated`, `plbot_not_defeated`, `mebot_not_defeated`, `libot_not_defeated`, `dabot_not_defeated`, `icbot_defeated`, `elbot_defeated`, `plbot_defeated`, `mebot_defeated`, `libot_defeated`, `dabot_defeated`, `aibot_not_defeated`, `cybot_not_defeated`, `wabot_not_defeated`, `eabot_not_defeated`, `fibot_not_defeated`, `aibot_defeated`, `wabot_defeated`, `eabot_defeated`, `fibot_defeated`, `coupled_corridors_found`, `exact_index`.
*	Added a special case for exact_index requirement string.
*	Fixed some issues with images not being animated correctly.
*	Added more sandbox features.<br>Y - toggles cooldown.<br>U - revives yourself.
*	Teleportation by sandbox features now places you back into safe zone.

## α1.14.3 - 08-03-24
*	Added some sandbox features.<br>E - teleports you 1 area back.<br>T - teleports you 1 area forward.<br>R - maxes out your hero card.
*	Added property `lightning_reduced` for region and area properties only.
*	Added spawner property `reverse` for Homing enemies only.
*	Fixed a bug where radar enemies wouldn't shoot whenever the player uses mouse movement.
*	Chat has been re-added back again.
*	Removed command "/crash" from the server as it is causing disruptions of getting the server itself (as "Ink Demon") consume you.

## α1.14.2 - 08-01-24
*	Accessory textures are no longer missing.
*	Frost Giant enemies now have a minimum interval of 33ms.
*	Fixed fake pumpkin enemies being rendered above player entities.

## α1.14.1 - 07-31-24
*	You can now cut objects with CTRL+X, copy objects with CTRL+C, and paste objects with CTRL+V at your mouse position.

## Minor Changes I (α1.14.0) - 07-30-24
*	Added property `share_to_drive`. (default: true)
*	Fixed a bug where ring projectiles that are rendered cause their health bar or energy bar to render incorrectly.
*	When the area is offscreen, the zone outlines will not render.

## α1.13.10 - 07-29-24
*	Region select is now re-enabled again.<sup>Resolved <a href="https://github.com/sonic3XE/evades-region-editor/issues/12">#12</a></sup>

## α1.13.9 - 07-27-24
*	Implemented Ring Sniper enemy.
*	Added more setting options for player accessory. (from /account page in Evades.io)
*	Accessory textures are currently missing.

## α1.13.8 - 07-26-24
*	Fixed a bug where attempting to copy after doing CTRL+A did not work properly.

## α1.13.7 - 07-18-24
*	Added spawner property `spawn_top` for Wall enemies only.

## 07-04-24
*	Happy Independence Day, everyone! There is no changes today.

## α1.13.6 - 06-16-24
*	Removed multiplayer communicating HUD (chat box) with a following context below:<br><img title="&lt;@701595179974393926&gt; Idc about screamers and stuff but i lost my fucking map bro this sucks so much" src="https://cdn.glitch.me/5f5113ca-1ab8-4f8a-8357-9d142d7b1103/1964c16f-1ff2-4cf8-b01f-0d340084746a.image.png" style="width:50%">
*	Added switch_time property to Switch enemies only.

## α1.13.5 - 06-15-24
*	Fixed a rendering issue with large values of X/Y position relative to area position.
*	Fixed an issue where some abilities are displayed incorrectly, causing them to not work properly when using.

## α1.13.4 - 06-14-24
*	Fixed a bug where zones and assets won't resize properly.

## α1.13.3 - 06-11-24
*	Added Leaderboard GUI for playtesting only.
*	Chat is added back for playtesting only.
*	Region Importer is added back but you can't load regions because it is disabled for some reasons.

## α1.13.2 - 06-10-24
*	Show amount of entities in the area.

## α1.13.1 - 06-09-24
*	Added Copy, Cut, and Paste option to the context menu for object actions only.
*	Allow to have multiple objects to be selected.

## α1.13.0 - 06-08-24
*	Fixed a bug where changing an asset type would not update the map properly.
*	Context Menu has been visually changed.
*	Added Rotate option to the context menu for object actions only.

## α1.12.11 - 06-07-24
*	Fixed a bug where exporting a region that contains control characters as a name caused to throw an error assuming that it failed to export.

## α1.12.10 - 06-02-24
*	Enemies added: flaming, stumbling, disarming, lurching, infectious, mutating from the future update of Evades.

## α1.12.9 - 05-26-24
*	Implement Tree, Lunging, Flower, Stalactite, Cactus, Static, Gravity Ghost, and Repelling Ghost enemies. Bringing up to a total of 83 enemy types

## α1.12.8 - 05-24-24
*	Fixed a bug where if you try to create or duplicate an area, it will throw an error.

## α1.12.7 - 05-20-24
*	Fonts that use Arial are no longer different than your "Arial" font in your device.

## α1.12.6 - 05-18-24
*	Implement Frost Giant enemy.

## α1.12.5 - 05-16-24
*	Added more settings for mouse movement, joystick, and display timer.

## α1.12.4 - 05-15-24
*	Fixed a performance issue where clicking too many times causes some lag spikes to occur.
*	Fixed a bug where clicking after selecting a zone or an asset will reset the spawn in the area.

## α1.12.3 - 05-14-24
*	Looks like the builtin system are starting to deteriorate as the game of evades keeps receiving any map updates.
*	Fixed some issues with region exporting throwing errors.
*	New property: Spawns Pellets (only works with area and zone properties)

## α1.12.2 - 05-12-24
*	Implement Cycling and Snowman enemy.

## α1.12.1 - 05-11-24
*	Fixed some issues where some inputs are not blurred if you are not playtesting.
*	Added confetti setting.
*	Dynamic Lighting, effects property are now properly working.
*	Implement Ability: Rime's Paralysis.

## α1.12.0 - 05-10-24
*	Fixed a bug where attempting to add or duplicate a zone would crash since the performance has been heavily optimized.
*	Fixed a bug where attmepting to press F4 to playtest would crash since there is no safezone flag set if you are contacting an aura.
*	Implement Wind Ghost, Residue, Seedling, Pumpkin, Sandrock, Sand, Wind Sniper, Radar, Fire Trail, Crumbling, Glowy, Firefly, Mist, Phantom, Grass, Ice Ghost, and Prediction Sniper enemies. Bringing up to a total of 72 vanilla enemies.

## α1.11.12 - 05-09-24
*	Implement Charging, Icicle, Ice Sniper, Speed Ghost, Poison Ghost, Regen Ghost, Disabling Ghost, Poison Sniper, Positive Magnetic Sniper, Negative Magnetic Sniper, Positive Magnetic Ghost, Lead Sniper, Force Sniper A, Force Sniper B, and Negative Magnetic Ghost enemies. Bringing up to a total of 55 vanilla enemies.

## α1.11.11 - 05-08-24
*	Fixed an issue where attempting to add or remove enemy type from/to the spawner will cause an error to occur.
*	Implement Speed Sniper, Regen Sniper enemies.
*	All assets are now entities.

## α1.11.10 - 05-07-24
*	Implement Radiating Bullets, Immune, Sniper, Corrosive, Corrosive Sniper, and possibly Wavy enemies.

## Final optimizations (α1.11.9) - 05-04-24
*	Game camera (in playtesting mode) has significantly changed. Added black bars to prevent seeing more than 40 x 23 tiles while playtesting.
*	Importing/Loading regions are now near instant.

## α1.11.8 - 05-03-24
*	Some optimizations e.g. Monumental Migration Hard loads around 5 seconds.
*	Fixed a visual bug where some images are visible after pressing F4 to enter playtesting mode for a short amount of time.
*	Implement Ability: Shade's Night

## α1.11.7 - 04-17-24
*	Show loading bar when all assets are not loaded.

## α1.11.6 - 04-13-24
*	Torch is now rendered as an entity.
*	Because of the excessive XSS in chat, the chat system has been removed.
*	Fixed rendering issues where AreaInfo was not scaled correctly.

## α1.11.5 - 04-12-24
*	Removed user Rainbow from the database.
*	User entities: ultimately scrapped for good.
*	Players can now collide with wall assets.

## α1.11.4 - 04-11-24
*	User tags in chat are now visible to others.
*	You can now hide chat, which also causes user entities to hide as well.

## α1.11.3 - 04-10-24
*	Warn users that connect to a chat with a proxy/vpn upon sending a message once.
*	You can now see other users when you are in the region editor.

## α1.11.2 - 04-09-24
*	A lot of changes to the chat server bruh.

## α1.11.1 - 04-08-24
*	Chatting system is now implemented.

## α1.11.0 - 04-07-24
*	Every time you playtest, the abilities will be reset.
*	Flashlight Ability added.
*	Flashlight Spawner is now rendered as an entity.
*	Fixed a bug where you can toggle minimap visibility while using input boxes that are not supposed to.
*	Fixed a rendering bug where torch and flashlight spawner texture is drawn at the incorrect position.
*	<a href="#AFU1">The Mysterious Event™</a> has been ended.

## α1.10.16 - 04-05-24
*	Addon `pncl9500` has been expanded.

## Seecret April Fools Update 1 (Joke α2.0.0) - 04-01-24
*	??????????<br><small>This event can occur annually.</small>

## α1.10.15 - 03-31-24
*	Rendering order of entities has been changed.
*	If you are wondering why can't you use default radius with enemy config in the original game, see <a href="https://github.com/Pifary-dev/ravel/pull/10#issuecomment-2028835998">this comment.</a>

## α1.10.14 - 03-29-24
*	[pncl9500]<br>Implement Switch, spiral, fake pumpkin, liquid, and switch enemies.

## α1.10.13 - 03-27-24
*	Fixed a bug where frost giant enemies do not spawn when the count is not specified.
*	[pncl9500]<br>Implement Sizing enemy.<br>Addons<br>Added `automationTools`.<br>Added `pncl9500`.

## α1.10.12 - 03-26-24
*	[pncl9500]: Implement Zoning, Zigzag, Oscillating, Star, Teleporting enemies.
*	Addon `pifary-dev` now has a complete list of additional enemies.

## α1.10.11 - 03-25-24
*	Addon `pifary-dev` has been added.
*	Fixed a bug where quicksand radius does not show correctly when placing a default value quicksand property.

## α1.10.10 - 03-11-24
*	Fixed some issues with blocking enemy.
*	Enabled discussion

## α1.10.9 - 03-04-24
*	Implement Ability: Jötunn's Decay

## α1.10.8 - 03-03-24
*	New Spawner property: quicksand_strength (default value of 5)
*	Added new Enemy Type: stalactite

## α1.10.7 - 03-02-24
*	Implement Ability: Chrono's Backtrack
*	Death timer text position on minimap is now corrected on a fixed scale.

## α1.10.6 - 03-01-24
*	Player now spawns at random position in first safe zone available.
*	Regions that are from the game now use the position from world.yaml

## 🧲 Magnetism! (α1.10.5) - 02-29-24
*	Magnetism mechanic is now implemented.
*	Implemented 3 more aura enemies:<br>magnetic_reduction<br>magnetic_nullification<br>blocking

## α1.10.4 - 02-28-24
*	Fixed some changelog date errors.

## α1.10.3 - 02-24-24
*	Fixed a visual issue where tile texture did not draw correctly with the specified texture selected.

## α1.10.2 - 02-18-24
*	Properties<br>Property `charge_reduced` added with a default value `false`.<br>Removed properties `radioactive_gloop_reduced` and `allow_solo_with_group`.
*	Fixed a bug where export does not work properly after overhaul.

## α1.10.1 - 02-17-24
*	Overhauled spawner to increase performance.
*	Overhauled properties to increase performance.

## α1.10.0 - 02-16-24
*	Important news from Stovoy:<br>I've been relaxing on the evenings by working on the new map editor 🙂<br>It's getting close to being releasable.<br>The official map editor will be integrated into the game and there will be a sharing system 🙂
*	UI<br>Spawner folder is closed by default instead of opened.
*	Context Menu<br>"Create Active Zone, Create Safe Zone, Create Exit Zone, etc." are now merged into "Create Zone".
*	Help<br>Screw you fldslpv_.<br>Added another category: UI.<br>Added section "Creating an object" to the UI category.
*	Fixed some input issues missing from Frost Giant Enemy.
*	Level<br>Leveling up is now instant compared to millions of levels with a while loop.
*	Experience<br>Formula is now less complex than the arrays.
*	Fixed a bug where quicksand enemies push you in opposite direction of the specified value.
*	Fixed a bug where homing enemies do not home on you in playtesting mode.
*	Region Importer<br>Fixed some ordering.

## α1.9.6 - 02-15-24
*	Enlarging Aura<br>Instead of player's radius multiplied by 1.667, player's radius is added by 10.

## α1.9.5 - 02-14-24
*	Fixed a bug where `inBarrier` flag is not set to false after contacting barrier enemy's aura.
*	Fixed an issue where changing the reducing aura changes the experience drain aura input box instead of itself.

## α1.9.4 - 02-13-24
*	Implemented 6 more aura enemies<br>barrier<br>gravity<br>repelling<br>slippery<br>quicksand<br>disabling
*	Fixed a bug where enlarging effect didn't work properly after 1 frame.<sup>Issue <a href="https://github.com/sonic3XE/evades-region-editor/issues/1">#1</a></sup>

## α1.9.3 - 02-12-24
*	Implemented 8 aura enemies<br>slowing<br>draining<br>experience_drain<br>freezing<br>reducing<br>enlarging<br>lava<br>toxic
*	You can now export a region in JSON format.

## α1.9.2 - 02-07-24
*	Fixed a bug where enemies can kill you in safe zone by going to the edge of active zone with high speeds.

## α1.9.1 - 02-06-24
*	Fixed a bug where 30FPS is not clocked correctly.

## α1.9.0_01 - 02-05-24
*	Removed some dead code (Unused code from Ng Kai Yan's SkapClient Editor).

## α1.9.0 - 02-04-24
*	Togglable 60FPS are now available in settings.
*	The first three abilities are now implemented.
*	Fixed visual minimap issue on Player Centered mode.
*	Fixed visual issues where death timer are not centered properly.
*	Fixed HeroInfoCard description line height scale not set.
*	Fixed visual minimap issue on Area Centered mode.

## α1.8.3 - 02-03-24
*	Fixed some visual minimap issues.<br>Removed errors from GameState.
*	Fetching world.yaml is now asynchronous.
*	Show an error whenever YAML fails to parse.
*	Fixed an issue where importing a builtin Withering Wasteland causes an duplicated mapping key error.

## α1.8.2 - 02-02-24
*	Top Left UI:<br>Added some spaces between Region Importer.
*	Region Importer:<br>Removed the arrow

## α1.8.1 - 01-29-24
*	New Enemy Types:<br>blocking<br>force sniper a<br>force sniper b

## Playtesting (α1.8.0) - 01-13-24
*	Playtesting feature has been implemented. Press F4 to playtest a region.

## Git (α1.7.7) - 12-24-23
*	You can create pull request whenever if you have a forked version of my repository.
*	You can now report the issue to my repository.

## α1.7.6 - 12-17-23
*	The old URLs were replaced with new URLs because it threw error 404 on discord embedded attachment.

## α1.7.5 - 12-05-23
*	You can now view issues by clicking on the Github issues icon.

## α1.7.4 - 12-03-23
*	Show zone and asset counter.

## α1.7.3 - 11-30-23
*	External enemy types tend to fall back to normal enemy.
*	Fixed an issue where external enemy types causes an error.
*	Removed en_us.json file because xhr said it's deprecated on main thread.
*	The unused "patterns" property in zone properties will never get to the Region Editor.

## α1.7.2 - 11-28-23
*	Add confirmation on deleting the area.
*	Some control issues are now resolved and mapped to the Virtual Key ID.
*	Push Direction is now optional for quicksand enemies.
*	Assigned default values for gravity and repulsion.

## α1.7.1 - 11-27-23
*	Area title is now updated according to the main Evades Renderer.
*	Property count now have a minimum of 0.
*	The Region Editor now checks for missing spawner properties that are from Evades.

## α1.7.0 - 11-26-23
*	Region Importer is now reenabled.
*	Fixed an issue where reducing radius was not updated properly.
*	Fixed an error on importing Cyber Castle and Transforming Turbidity due to duplicated mapping key.
*	Pellet spawner is now allowed to spawn in multiple active zones.
*	Fixed an error where fetching world.yaml does not exist because of the main root is used instead.
*	Fixed visual issue where text wasn't translating properly
*	Permanent lock screen has been removed. (Where it has sonic.exe image with the text "You're serious.")
*	The Region Editor has been grown very quickly. Thanks to Kaluub for including all region files.
*	The Region Editor has been migrated to GitHub because Replit decides to <a href="https://status.replit.com/history/2023/december/fwaqhkavzwyaywfs-secrets-env-variables-are-missing">make my region editor stop hosting for some reason</a>.

## α1.6.6 - 11-25-23
*	Update area in real time is no longer forced OFF.
*	Most enemy types that aren't on that list were fell back into default behavior (move in straight line). Enemies with auras stay as it is.

## α1.6.5 - 11-23-23
*	Region Importer is disabled.
*	Zone positions/sizes and area positions update only after moving or resizing.

## α1.6.4 - 11-16-23
*	The Region Editor is back but with "update area in real time" being forced OFF due to one of the reasons:<br>We are not interested in giving out enemy files. - PotatoNuke

## THE IMPACT - Early November 2023
*	[Nov08]: The Region Editor is down due to lack of Enemy/Projectile PY files.
*	[Nov05]: The moderator iroquois_pliskin63 noticed that some enemy types crashed the editor.

## α1.6.3 - 10-30-23
*	Pellet spawner now spawn at multiple victory zones in an area instead of one victory zone.

## α1.6.2 - 10-24-23
*	Fixed raw translation of Fake Pumpkin Enemy.
*	Fixed an error where posY did not exist.

## α1.6.1 - 10-23-23
*	New option to start from scratch.

## α1.6.0 - 10-16-23
*	Region Importer is now added.
*	Fixed a bug where if you dont have internet, you can't access to the region until connected again, causing the editor to lock up.
*	Added Spawner Properties:<br>hard_mode
*	Added Requirements:<br>inaccessible<br>ten_hard_variants<br>cybot_hard_boss_defeated

## α1.5.5 - 09-20-23
*	Now possible to select zones or assets with negative sizes.

## α1.5.4 - 09-13-23
*	Movable settings now have "X" button which closes settings and display settings icon at bottom right next to question icon.
*	Added settings launcher (opens settings, hides settings icon).

## α1.5.3 - 09-11-23
*	Fixed an issue where enemy spawner couldn't be removed or cloned on new active zone.

## α1.5.2 - 09-09-23
*	Mouse movement no longer reset the area constantly.

## α1.5.1 - 09-08-23
*	Category Area:<br>Added "Changing area background color" to the Area category.

## α1.5.0 - 09-07-23
*	The help has arrived...
*	Category Area:<br>Added "Adjusting Area Position" to the Area category.<br>Added "View other areas" to the Area category.

## α1.4.7 - 08-27-23
*	Fixed an error upon duplicating spawners.

## α1.4.6 - 08-17-23
*	Fixed an issue where undefined values in region properties treated as empty string on importing.

## App Installations (α1.4.5) - 08-11-23
*	The manifest file is fetched upon loading the webpage.

## α1.4.4 - 08-09-23
*	Fixed an issue where entity can go NaN when there is 2 values in spawner data's X or Y positions.
*	Fixed an issue where spawner speed is not specified, causing entities to move at 5 speed instead.
*	`last_` variables update when zone positions or size is changed instead of constantly updating.
*	Creating a zone will now be placed at the context menu with a size of 160x160 pixels instead of resize at mouse position
*	Implemented wall asset collision for any entity.

## α1.4.3 - 08-03-23
*	If the property radius is not specified, the default radius vary on the respective enemy type via Evades.io Config.

## α1.4.2 - 08-02-23
*	Positions that are outside of the signed 32-bit integer range will not be visible.

## α1.4.1 - 07-20-23
*	Fixed an issue where enemies that spawn at random positions could spawn at the same spot as the previous enemy spawner position specified.

## α1.4.0 - 07-19-23
*	New visualization for translate properties: Arrows<br>Exit Zone: Yellow arrow<br>Teleport Zone: Magenta arrow<br>Arrows are only visible when you select teleport or exit zone.
*	You can now duplicate the current area.
*	You are no longer to duplicate a(n) zone/asset on entering another area.

## Fixes (α1.3.7) - 07-17-23
*	Fixed an issue where spawners could cause an error on export.
*	Fixed an issue where cloning or adding a spawner causes errors for html elements on click.<br>This should fix the lag spikes when there is too many html elements stored in a variable.
*	Fixed an issue where deleting an area could not spawn entities on available area.

## Performance Improvement (α1.3.4) - 07-15-23
*	Only zone or asset that was selected or an area you are currently in will show GUI.
*	Leaving an area will remove entities.<br>This should fix the lag spikes when there is too many html elements stored in a variable.

## α1.3.3 - 07-13-23
*	New Setting: Tile Mode

## α1.3.2 - 07-12-23
*	If there is no zones provided, a placeholder with a size of your snapping is placed for temporary.

## α1.3.1 - 07-11-23
*	Clone (+) and Remove (×) buttons are now assigned to a color whereas red is remove, green is clone, and white text for both buttons.
*	Parity Issue Fix: Missing feature to duplicate spawners

## The Simulation Update (α1.3.0) - 07-10-23
*	Area Simulation has been implemented.
*	Custom snapping is added to make it more or less precise position on changing value.
*	Clicking on create zone no longer gets misaligned as you click on the target position
*	If there is unnecessary gap between the origin and most topleft zone, the area will shift the zones and change area position.
*	Instead of negative positions for zones in its area, the area will shift the zones and change area position.

## α1.2.5 - 07-07-23
*	New property: allow_solo_with_group added to properties folder.

## α1.2.4 - 07-04-23
*	Fixed an issue where color values that are not integer will throw an error.

## α1.2.3 - 07-03-23
*	Folders inside types folder has been removed as with 1 property inside.
*	Camera scale is now restricted between 1/65536 and 65536.
*	Fixed an issue where the zone that was duplicated didn't preserve last_ variables.
*	Duplicating a zone or asset that was selected will select the duplicated object.
*	Folders inside types folder has been removed as with 1 property inside.

## α1.2.2 - 07-02-23
*	Region editor no longer have different fonts in different devices.

## α1.2.1 - 07-01-23
*	New property added to properties: sticky_coat_distort_reduced (Default: False)
*	Fixed an issue where map properties are all undefined values
*	Improved renderer.<br>Removed context transforms except zones and wall assets.<br>Removed lighting context transforms completely

## α1.2.0 - 06-30-23
*	Fixed an issue where you try to change projectile duration could cause you to change radius instead.
*	Fixed an issue where changing pellet count will throw an error of `ReferenceError: pellet_count is not defined`.
*	Fixed an issue where you can change the zone width or height to negative values, unable to get selected after.
*	Fixed an issue where you can create the zone with negative width or height via context menu.
*	Fixed an issue where you change x or y values does not sync correctly with raw x or y values.

## α1.1.5 - 06-28-23
*	Fixed an issue where changing color of duplicated zone causes other zones to change color.
*	Background color will now get ignored if alpha is 0 and color is pure black (#000000) upon export.
*	All zone positions/sizes and area positions now receive updates on area creation.
*	Area bounding box is now shown with lime outline.
*	Removed `Create Gate` from context menu.

## α1.1.4 - 06-27-23
*	Fixed an issue where exporting an area will cause an error to occur.

## α1.1.3 - 06-26-23
*	applies_lantern (boolean, false) property is added to object `properties`.

## α1.1.2 - 06-12-23
*	Zone position/size and Asset position/size now rounds to the nearest half tile.

## α1.1.1 - 06-07-23
*	Fixed an issue where after creating a zone, the raw width/height doesnt sync correctly after zone creation.
*	Areas and zones now only update when resizing, moving, and inputting is active.
*	~~Fixed zone background color changing other zone background color.~~

## Supporting `last_` variables! (α1.1.0) - 06-04-23
*	~~Zone positions no longer have negative x and y in areas.~~
*	last_ variables are now available to use for inputting x, y, width, and height for zones and areas only.
*	Area positions are always updated depending on the width/height of the area.
*	Zone positions are always updated depending on the x/y/width/height of the zone.
*	You are no longer to click twice on creating the area. (simply click create area and press right arrow)

## α1.0.10 - 04-09-23
*	Added property push_direction to quicksand enemy only<br>Fixed a bug where all last_ variables were not translated to number correctly for area positioning

## α1.0.9 - 02-17-23
*	Fixed an issue where light regions causes an error upon export.

## α1.0.8 - 01-24-23
*	New Zone: Dummy

## α1.0.7 - 12-18-22
*	Fixed some issues due to export region fail.<br>If values x, y, or angle is blank, the yaml output will exclude that property.

## α1.0.6 - 12-12-22
*	Angle property has moved to Enemy Position &amp; Angle.
*	More requirement values added: Research Lab Discovered, All Heroes Unlocked, Mystery Keycard, Cybot Defeated, All Elements Gained

## α1.0.5 - 12-11-22
*	Cybot, Aibot, Wabot, Eabot, Fibot, Barrier, Radar, Sand, Sandrock, Crumbling, Wind Sniper, Quicksand enemy types are added.

## α1.0.4 - 12-04-22
*	2 new enemy types has added<br>4 enemy spawner properties has added

## α1.0.3 - 11-01-22
*	Disabling Ghost, Mist, Phantom, Glowy, and Firefly enemy types are added.

## α1.0.2 - 10-24-22
*	You can now duplicate an object you selected

## α1.0.1 - 08-05-21
*	Color issue fixed if numbers are strings.
## UI Change - 07-30-21
*	Map Editor enters alpha stage. (α1.0.0)
*	Tile snapping.
*	The UI has been changed.<br>UI design by Ng Kai Yan (NKY5223)
## 07-21-21
*	Area Properties are added to Map Editor.
## 07-20-21
*	Region Properties are added to Map Editor.
## 06-27-21
*	Added enemy type **fire_trail** to map editor.
## 06-24-21
*	Prompt map name before saving if the map name doesn't exist.
## 06-23-21
*	Added more zones.
## 06-20-21
*	You are no longer go beyond the area count after you choose a file.
## 06-18-21
*	Areas now no longer get misaligned.
## 06-17-21
*	Areas now have a minimum of 1. You are no longer go over the area count if you delete an area.
*	Fixed a bug where you select a block and deleting an area causes white screen.
