//  , prec=loadImage("https://cdn.glitch.me/4777c7d0-2cac-439c-bde4-07470718a4d7/jumpscare.mp3")
//  , errorFX = loadImage('https://s.jezevec10.com/res/se2/topout.mp3')
//  , VFX = loadImage("https://cdn.glitch.me/4777c7d0-2cac-439c-bde4-07470718a4d7/mus_gameOver.ogg")
let playtesting = false
  , isFinish = false
  , isPrivateBuild = true
  , canvasLighting = createOffscreenCanvas(window.innerWidth, window.innerHeight)
  , evadesRenderer = {
	snowRenderer: new SnowRenderer,
	sakuraRenderer: new SakuraRenderer,
	dynamicLighting: new DynamicLighting(1)
};
function formatByteSizes(x){
  let indexes=["B","kB","MB","GB"];
  let powOf = Math.floor(Math.max(0,Math.log(x)/Math.log(1024)));
  return `${(x/1024**powOf).toFixed((!!powOf)&&(x/1024**powOf < 100))} ${indexes[powOf]}`
}
const defaultHighestAreaAchieved = function(){
const e = {"Central Core":40,"Central Core Hard":40,"Catastrophic Core":40,"Vicious Valley":40,"Vicious Valley Hard":40,"Elite Expanse":80,"Elite Expanse Hard":80,"Wacky Wonderland":80,"Wacky Wonderland Hard":0,"Glacial Gorge":40,"Glacial Gorge Hard":40,"Dangerous District":80,"Dangerous District Hard":80,"Peculiar Pyramid":31,"Peculiar Pyramid Hard":31,"Monumental Migration":480,"Monumental Migration Hard":1920,"Humongous Hollow":80,"Humongous Hollow Hard":0,"Haunted Halls":16,"Frozen Fjord":40,"Frozen Fjord Hard":40,"Transforming Turbidity":0,"Quiet Quarry":80,"Quiet Quarry Hard":40,"Ominous Occult":16,"Ominous Occult Hard":16,"Restless Ridge":43,"Restless Ridge Hard":48,"Toxic Territory":20,"Toxic Territory Hard":20,"Magnetic Monopole":36,"Magnetic Monopole Hard":34,"Assorted Alcove":40,"Assorted Alcove Hard":28,"Burning Bunker":36,"Burning Bunker Hard":36,"Grand Garden":28,"Grand Garden Hard":28,"Endless Echo":1560,"Endless Echo Hard":54,"Mysterious Mansion":62,"Coupled Corridors":64,"Cyber Castle":16,"Cyber Castle Hard":0,"Research Lab":41,"Shifting Sands":47,"Infinite Inferno":38,"Dusty Depths":0,"Withering Wasteland":35,"Terrifying Temple":0,"Stellar Square":0};
for(const item in e)e[item]=999;return e;}();
function arrow(e, a, t, r, c, o=2, n=15, $="#cc000088", _="#FF0000") {
	if(a==r&&t==c)return;
    const d = Math.atan2(c - t, r - a);
    const dist = Math.sqrt((c - t)**2+(r - a)**2);
    e.moveTo(a+o/4*Math.sin(d), t-o/4*Math.cos(d)),
    e.lineTo(a-o/4*Math.sin(d), t+o/4*Math.cos(d)),
    e.lineTo(r-o/4*Math.sin(d)-Math.min(o,dist)/2*Math.cos(d), c+o/4*Math.cos(d)-Math.min(o,dist)/2*Math.sin(d)),
    e.lineTo(r-o/2*Math.sin(d)-Math.min(o,dist)/2*Math.cos(d), c+o/2*Math.cos(d)-Math.min(o,dist)/2*Math.sin(d)),
    e.lineTo(r, c),
    e.lineTo(r+o/2*Math.sin(d)-Math.min(o,dist)/2*Math.cos(d), c-o/2*Math.cos(d)-Math.min(o,dist)/2*Math.sin(d)),
    e.lineTo(r+o/4*Math.sin(d)-Math.min(o,dist)/2*Math.cos(d), c-o/4*Math.cos(d)-Math.min(o,dist)/2*Math.sin(d)),
    e.lineTo(a+o/4*Math.sin(d), t-o/4*Math.cos(d))
}
function controlPlayer(id,input,delta){
	var player=world.players.filter(e=>e.id==id)[0];
	if(player)player.controlActions(input,delta);
}
function arrayToInt32(s){
	return new DataView(new Int8Array(s).buffer).getUint32();
}
function render(delta) {
	ctx.resetTransform();
  const selfPlayer = world.players.filter(e => e.id == window.selfId)[0] || null, ctxL = canvasLighting.getContext("2d");
	if(!isFinish)
		$e7009c797811e935$export$2e2bcd8739ae039.start({drawUI:true}),
		$e7009c797811e935$export$2e2bcd8739ae039.registerListeners(),
		isFinish = true;
	$e7009c797811e935$export$2e2bcd8739ae039.update($e7009c797811e935$export$2e2bcd8739ae039.gameState, Cam);
  if(!playIcons.done){
    playIcons.time += delta;
    function play_button_lerp(x){
      x=clamp(x,0,1);
      return((8*x-9)*x+6)*x/5;
    }
    const curCon = playIcons.prev.split("d=")[1].split("\"")[1];
    const newCon = playIcons[playtesting ? "pause" : "play"].split("d=")[1].split("\"")[1];
    const Puc = function(p) {
      var l = [];
      p = p.match(/[0-9.-]+|[^0-9.-]+/g);
      for (var Q = 0; Q < p.length; Q++) {
        var H = p[Q] === " " ? NaN : Number(p[Q]);
        l.push(isNaN(H) ? p[Q] : H)
      }
      return l
    }, UMX = function(p, l, Q) {
      for (var H = "", q = 0; q < p.length; q++) {
        var W = p[q];
        H = typeof W === "number" ? H + (W + (l[q] - W) * Q) : H + W
      }
      return H
    };
    playtester.querySelector("path").setAttribute("d",UMX(Puc(curCon),Puc(newCon),play_button_lerp(playIcons.time/playIcons.duration)));
    if(playIcons.time > playIcons.duration)playIcons.done=true,playIcons.time=playIcons.duration;
  };
	closeSettings.style.top = tip.scrollTop + "px";
	if (canvas.width !== window.innerWidth || canvas.height !== window.innerHeight){
		let $$ = {
			x: window.innerWidth / 1280,
			y: window.innerHeight / 720
		}, top = 0, left = 0;
    $$.x<$$.y?($$ = $$.x, top = (window.innerHeight - Math.ceil(720 * $$)) / 2):($$ = $$.y, left = (window.innerWidth - Math.ceil(1280 * $$)) / 2);
		if($$ !== Cam.originalGameScale)
			Cam.originalGameScale=$$,
			canvas.width = Math.ceil($$*1280),
			canvas.height = Math.ceil($$*720),
			canvasLighting.width = canvas.width,
			canvasLighting.height = canvas.height,
			Cam.viewportSize.width = canvas.width,
			Cam.viewportSize.height = canvas.height,
			Cam.updateBounds(),
			canvas.setAttribute("style",`top:${top}px;left:${left}px;cursor:none`),
			resizeWebGl();
	};
	if (playtesting){
		if (selfPlayer == null && window.selfId != null)
			stopPlaytesting(),
			spawnEntities(current_Area);
		else
			Cam.centerOn(selfPlayer),
			current_Area = selfPlayer.area,
			current_Region = selfPlayer.region;
	}else{
		let newPos = {
			x: Cam.centerX + camSpeed * 60 / Cam.getScale() * (keysDown.has(controls.CAM_RIGHT) - keysDown.has(controls.CAM_LEFT)) * delta / 1e3,
			y: Cam.centerY + camSpeed * 60 / Cam.getScale() * (keysDown.has(controls.CAM_DOWN) - keysDown.has(controls.CAM_UP)) * delta / 1e3
		};
		Cam.centerOn(newPos);
		(keysDown.has(controls.CAM_RIGHT) - keysDown.has(controls.CAM_LEFT) === 0 && keysDown.has(controls.CAM_DOWN) - keysDown.has(controls.CAM_UP) === 0) || (updateSelectMode(), global.onmousemove && global.onmousemove());
	}
	mousePos.ex=clamp(mousePos.ex,-canvas.width/2,canvas.width/2);
	mousePos.ey=clamp(mousePos.ey,-canvas.height/2,canvas.height/2);
	const region = world.regions[current_Region]
	  , area = region?.areas?.[current_Area]
	  , matrix = new DOMMatrix([Cam.getScale(), 0, 0, Cam.getScale(), canvas.width / 2 - Cam.centerX * Cam.getScale(), canvas.height / 2 - Cam.centerY * Cam.getScale()])
	  , prop = (e, a, s) => e[a][s]
	  , propDefault = (a, s) => (defaultValues[a][s])
	  , s = (e, s, z, a, r) => ((z && void 0 !== prop(z, e, s)) ? prop(z, e, s) : (void 0 !== prop(a, e, s)) ? prop(a, e, s) : (prop(r, e, s) ?? propDefault(a, s)));
	ctx.fillStyle=tileMode.selectedIndex>>1?"#050505FF":"#333333FF",
	ctx.fillRect(0,0,canvas.width,canvas.height);
	ctxL.clearRect(0, 0, innerWidth, innerHeight);
	ctx.imageSmoothingQuality = "high";
	ctx.imageSmoothingEnabled = true;
	let camRect = {x:Cam.left,y:Cam.top,width:Cam.right-Cam.left,height:Cam.bottom-Cam.top};
	if(area){
	for(const zone of area.zones){
		if (!rectRectCollision(zone, camRect))
			continue;
		let texture = s("properties", "texture", zone, area, region)
		  , color = [...s("properties", "background_color", zone, area, region)]
		  , isSolid = color[3] === 255, isInvis = color[3] === 0, p;
		if(!isSolid)p=ctx.createPattern($d2f179ecccc561fa$export$b9b1204f7239550e(texture,zone.type,settings.tileMode).image.getImage(),null),p.setTransform(new DOMMatrix([Cam.getScale(),0,0,Cam.getScale(),canvas.width/2-Cam.centerX%$d2f179ecccc561fa$var$getTextureSize(texture)*Cam.getScale(),canvas.height/2-Cam.centerY%$d2f179ecccc561fa$var$getTextureSize(texture)*Cam.getScale()]));
		settings.tileMode > 1 && 858993663 == arrayToInt32(color) && (color = [5, 5, 5, 255]),
		settings.tileMode > 1 || 84215295 != arrayToInt32(color) || (color = [51, 51, 51, 255]),
		ctx.beginPath(),
		ctx.moveTo(clamp(Math.round(Cam.getX(zone.x)),0,canvas.width), clamp(Math.round(Cam.getY(zone.y)),0,canvas.height)),
		ctx.lineTo(clamp(Math.round(Cam.getX(zone.x)+Cam.toScale(zone.width)),0,canvas.width), clamp(Math.round(Cam.getY(zone.y)),0,canvas.height)),
		ctx.lineTo(clamp(Math.round(Cam.getX(zone.x)+Cam.toScale(zone.width)),0,canvas.width), clamp(Math.round(Cam.getY(zone.y)+Cam.toScale(zone.height)),0,canvas.height)),
		ctx.lineTo(clamp(Math.round(Cam.getX(zone.x)),0,canvas.width), clamp(Math.round(Cam.getY(zone.y)+Cam.toScale(zone.height)),0,canvas.height)),
		!isSolid&&(ctx.fillStyle=p,ctx.fill()),
		!isInvis&&(ctx.fillStyle=RGBAtoHex(color),ctx.fill()),
		ctx.closePath()
	};
	var entities = sortEntitiesByZIndex(area.entities.concat(world.players)).filter(e=>e.area==current_Area&&e.region==current_Region);
	ctx.textAlign = "center",
	ctx.textBaseline = "alphabetic";
	EvadesEntity.renderEntitiesEffects(ctx,Cam,entities);
	for (const entity of entities) {
		ctx.lineWidth = Cam.toScale(1);
		entity.render(ctx, Cam, delta);
		if(-1!==notSimulatingEntities.indexOf(entity))
			ctx.font=`${Cam.toGuiScale(30)}px fnt_barrio`,
			ctx.lineJoin="round",
			ctx.lineWidth=Cam.toGuiScale(5),
			ctx.strokeStyle="black",
			ctx.strokeText("Not simulating",Cam.getX(entity.x),Cam.getY(entity.y)),
			ctx.lineJoin="miter",
			ctx.fillStyle="white",
			ctx.fillText("Not simulating",Cam.getX(entity.x),Cam.getY(entity.y))
	};
	if (s("properties", "lighting", null, area, region) < 1) {
		evadesRenderer.dynamicLighting.lighting = s("properties", "lighting", null, area, region);
		evadesRenderer.dynamicLighting.circleLightSources.length = 0;
		evadesRenderer.dynamicLighting.coneLightSources.length = 0;
		evadesRenderer.dynamicLighting.rectangleLightSources.length = 0;
		for (const entity of entities) {
			null !== entity.lightRadius && evadesRenderer.dynamicLighting.addCircleLightSource(entity.lightRadius, entity.x, entity.y, entity.lightColor||"#FFFFFF");
			null !== entity.lightRectangle && evadesRenderer.dynamicLighting.addRectangleLightSource(entity.lightRectangle);
			entity.burning && evadesRenderer.dynamicLighting.addCircleLightSource(4 * entity.radius, entity.x, entity.y);
			for (const effect of entity.getEffectConfigs())
				effect.hasLight && (effect.cone && evadesRenderer.dynamicLighting.addConeLightSource(entity.x, entity.y, entity.radius, effect.inputAngle, effect.cone.innerAngle * Math.PI / 180, effect.cone.distance),
				effect.circle && evadesRenderer.dynamicLighting.addCircleLightSource(effect.circle.radius, entity.x, entity.y, "#FFFFFF"));
		}
		evadesRenderer.dynamicLighting.render(ctxL, Cam);
		ctx.globalCompositeOperation = "multiply";
		ctx.drawImage(canvasLighting, 0, 0);
		ctx.globalCompositeOperation = "source-over";
	};
	evadesRenderer.snowRenderer.update(area, ctx, Cam, s, delta);
	evadesRenderer.snowRenderer.render(ctx, Cam);
	evadesRenderer.sakuraRenderer.update(area, ctx, Cam, s, delta);
	evadesRenderer.sakuraRenderer.render(ctx, Cam);
	ctx.lineWidth=Cam.toGuiScale(2);
	ctx.strokeStyle=s("properties","lighting",null,area,region)>0.5&&tileMode.selectedIndex>>1==0?"black":"white";
	area.zones.length==0&&ctx.strokeRect(Cam.getX(0),Cam.getY(0),Cam.toScale(settings.snapX),Cam.toScale(settings.snapY));
	if (hitbox&&!playtesting) {
		for (const Area of region.areas) {
			if (!rectRectCollision({...Area.boundary, x: Area.x - area.x, y: Area.y - area.y}, camRect))
				continue;
			for (const zone of Area.zones) {
				if (!rectRectCollision({...zone, x: Area.x - area.x + zone.x, y: Area.y - area.y + zone.y}, camRect))
					continue;
				ctx.strokeRect(Cam.getX(Area.x-area.x+zone.x)+ctx.lineWidth/2,Cam.getY(Area.y-area.y+zone.y)+ctx.lineWidth/2,Math.max(0,Cam.toScale(zone.width)-ctx.lineWidth),Math.max(0,Cam.toScale(zone.height)-ctx.lineWidth))

			}
			for (const asset of Area.assets){
				if((asset.type==="flashlight_spawner"||asset.type==="torch")&&rectCircleCollision(Area.x-area.x+asset.x,Area.y-area.y+asset.y,16,camRect.x,camRect.y,camRect.width,camRect.height).c)
					ctx.beginPath(),
					ctx.ellipse(Cam.getX(Area.x-area.x+asset.x),Cam.getY(Area.y-area.y+asset.y),Math.max(0,Cam.toScale(16)-ctx.lineWidth),Math.max(0,Cam.toScale(16)-ctx.lineWidth),0,0,Math.PI*2),
					ctx.stroke(),
					ctx.closePath();
				else if(rectRectCollision({...asset, x: Area.x - area.x + asset.x, y: Area.y - area.y + asset.y}, camRect))
					ctx.strokeRect(Cam.getX(Area.x-area.x+asset.x)+ctx.lineWidth/2,Cam.getY(Area.y-area.y+asset.y)+ctx.lineWidth/2,Math.max(0,Cam.toScale(asset.width)-ctx.lineWidth),Math.max(0,Cam.toScale(asset.height)-ctx.lineWidth))
			}
		}
	}
	for (const zone of area.zones) {
		if (playtesting)
			break;
		if (!rectRectCollision({...zone,x:zone.x+zone.translate.x,y:zone.y+zone.translate.y}, camRect) || !(zone.type === "exit" || zone.type === "teleport"))
			continue;
		ctx.fillStyle=zone.type==="teleport"?"#FF00FF66":"#FFFF0066",
		ctx.fillRect(Cam.getX(zone.x+zone.translate.x),Cam.getY(zone.y+zone.translate.y),Cam.toScale(zone.width),Cam.toScale(zone.height));
	ctx.lineWidth=Cam.toGuiScale(2);
	}
	for(const obj of selectedObjects) {
		ctx.strokeStyle="#FF0000FF";
		if (playtesting)
			break;
		if ((obj.type === "flashlight_spawner" || obj.type === "torch")&&rectCircleCollision(obj.x,obj.y,16,camRect.x,camRect.y,camRect.width,camRect.height).c)
			ctx.beginPath(),
			ctx.ellipse(Cam.getX(obj.x),Cam.getY(obj.y),Math.max(0,Cam.toScale(16)-ctx.lineWidth),Math.max(0,Cam.toScale(16)-ctx.lineWidth),0,0,Math.PI*2),
			ctx.stroke();
		else if (obj.type === "teleport" || obj.type === "exit")
			rectRectCollision(obj,camRect)&&ctx.strokeRect(Cam.getX(obj.x)+ctx.lineWidth/2,Cam.getY(obj.y)+ctx.lineWidth/2,Math.max(0,Cam.toScale(obj.width)-ctx.lineWidth),Math.max(0,Cam.toScale(obj.height)-ctx.lineWidth)),
			ctx.beginPath(),
			ctx.strokeStyle = obj.type == "teleport" ? "#800080" : "#808000",
			ctx.fillStyle = obj.type == "teleport" ? "#FF00FF" : "#FFFF00",
			ctx.lineWidth=Cam.getScale(),
			arrow(ctx, Cam.getX(obj.x + obj.width / 2), Cam.getY(obj.y + obj.height / 2), Cam.getX(obj.x + obj.width / 2 + obj.translate.x), Cam.getY(obj.y + obj.height / 2 + obj.translate.y), Cam.toScale(32), 2),
			ctx.closePath(),
			ctx.fill(),
			ctx.stroke(),
			ctx.lineWidth=Cam.toGuiScale(2);
		else
			rectRectCollision(obj,camRect)&&ctx.strokeRect(Cam.getX(obj.x)+ctx.lineWidth/2,Cam.getY(obj.y)+ctx.lineWidth/2,Math.max(0,Cam.toScale(obj.width)-ctx.lineWidth),Math.max(0,Cam.toScale(obj.height)-ctx.lineWidth))
	}
	if (selectionArea)
		ctx.fillStyle = "#2F3AB080",
		ctx.beginPath(),
		ctx.rect(Cam.getX(selectionArea.x),Cam.getY(selectionArea.y),Cam.toScale(selectionArea.width),Cam.toScale(selectionArea.height)),
		ctx.strokeStyle = "#2F3AB0FF",
		ctx.fill(),
		ctx.stroke(),
		ctx.closePath();
	ctx.textBaseline = "alphabetic";
	if (hitbox && !playtesting && area.boundary)
		ctx.strokeStyle = "#00FF00FF",
		ctx.strokeRect(Cam.getX(area.boundary.left) - ctx.lineWidth/2, Cam.getY(area.boundary.top) - ctx.lineWidth/2, Cam.toScale(area.boundary.width) + ctx.lineWidth, Cam.toScale(area.boundary.height) + ctx.lineWidth),
		ctx.strokeStyle = "#0000FFFF",
		ctx.strokeRect(Cam.getX(area.boundary.left-2000) + ctx.lineWidth/2, Cam.getY(area.boundary.top-2000) + ctx.lineWidth/2, Math.max(0,Cam.toScale(area.boundary.width+4000) - ctx.lineWidth), Math.max(0,Cam.toScale(area.boundary.height+4000) - ctx.lineWidth));
	ctx.lineWidth = Cam.getScale();
	}
	if (playtesting) {
		if(evadesRenderer.directionalIndicatorHud)
      evadesRenderer.directionalIndicatorHud.update(world.players, {id: selfPlayer.id, entity: selfPlayer}, area);
		if(evadesRenderer.titleText)
      evadesRenderer.titleText.unionState({...selfPlayer, regionName: world.regions[current_Region].name, areaNumber: current_Area + 1, titleStrokeColor: arrayToInt32(s("properties","title_stroke_color",null,area,region)), bossArea: area.boss||false, victoryArea: area.zones.some(e => e.type === "victory"), areaName: area.name || String(current_Area + 1)});
    if(evadesRenderer.fpe_teach_icons)
      evadesRenderer.fpe_teach_icons.unionState(selfPlayer);
		if(evadesRenderer.experienceBar)
      evadesRenderer.experienceBar.unionState(selfPlayer);
		if(evadesRenderer.heroInfoCard)
      evadesRenderer.heroInfoCard.unionState(selfPlayer);
		if(evadesRenderer.overlayText)
      evadesRenderer.overlayText.unionState(selfPlayer);
		if(evadesRenderer.minimap)
      evadesRenderer.minimap.update(world.players, area.entities, {entity: selfPlayer}, area),
		  evadesRenderer.minimap.unionState({x: area.x + selfPlayer.x, y: area.y + selfPlayer.y});
		if(evadesRenderer.areaInfo)
      evadesRenderer.areaInfo.update({entity: selfPlayer}, area);
		for (let cls in evadesRenderer) {
			const renderer = evadesRenderer[cls];
			if ((renderer instanceof SnowRenderer) || (renderer instanceof DynamicLighting))
				continue;
			renderer.render(ctx, Cam, $e7009c797811e935$export$2e2bcd8739ae039.gameState, delta)
		}
	};
	ctx.textAlign = "center";
	if(regionIsLoading)
		ctx.fillStyle = "#00000080",
		ctx.font = `bold ${$f36928166e04fda7$export$2e2bcd8739ae039.font(Cam.toGuiScale(36))}`,
		ctx.fillRect(0,0,ctx.canvas.width,ctx.canvas.height),
		ctx.fillStyle = "white",
		ctx.fillText("Loading region(s)...",ctx.canvas.width/2,ctx.canvas.height/2);
	if(area){
	ctx.strokeStyle = RGBAtoHex(s("properties", "title_stroke_color", null, area, region));
	ctx.fillStyle = "#F4FAFFFF";
	let areaname = String(area.name || (current_Area + 1))
	  , rs = isNaN(parseInt(areaname)) ? areaname : `Area ${areaname}`
	  , cs = `${region.name}: ${rs}`;
	region.areas.length == 1 && (cs = `${region.name}`),
	region.name.length || (cs = rs),
	area.zones.some(e => e.type == "victory") ? (cs = `${region.name}: Victory!`) : area.boss && (cs = `${region.name}: BOSS AREA ${areaname}`);
	ctx.lineJoin = "round";
  let plrs = world.players.filter(e=>e.area==current_Area&&e.region==current_Region);
	if (!playtesting)
		ctx.lineWidth = Cam.toGuiScale(6),
		ctx.font = `bold ${$f36928166e04fda7$export$2e2bcd8739ae039.font(Cam.toGuiScale(35))}`,
		ctx.strokeText(cs, canvas.width / 2, Cam.toGuiScale(40)),
		ctx.fillText(cs, canvas.width / 2, Cam.toGuiScale(40)),
		ctx.font = `bold ${$f36928166e04fda7$export$2e2bcd8739ae039.font(Cam.toGuiScale(25))}`,
		ctx.strokeText(`# of zones: ${area.zones.length}`, canvas.width / 2, Cam.toGuiScale(75)),
		ctx.fillText(`# of zones: ${area.zones.length}`, canvas.width / 2, Cam.toGuiScale(75)),
		ctx.strokeText(`# of assets: ${area.assets.length}`, canvas.width / 2, Cam.toGuiScale(100)),
		ctx.fillText(`# of assets: ${area.assets.length}`, canvas.width / 2, Cam.toGuiScale(100)),
		ctx.strokeText(`# of entities: ${area.entities.length+plrs.length}`, canvas.width / 2, Cam.toGuiScale(125)),
		ctx.fillText(`# of entities: ${area.entities.length+plrs.length}`, canvas.width / 2, Cam.toGuiScale(125));
	}
	ctx.strokeStyle = "#000";
	ctx.lineWidth = Cam.toGuiScale(4);
	ctx.font = `bold ${$f36928166e04fda7$export$2e2bcd8739ae039.font(Cam.toGuiScale(15))}`;
	ctx.textBaseline = "middle";
	ctx.textAlign = "right";
	ctx.fillStyle="white";
	if(isPrivateBuild)version[0]=version[1]=version[3]="",version[2]=". Real convincing sign, huh?";
	ctx.strokeText(`${isPrivateBuild ? "" : "Evades Region Editor "}${version[3]}${version[0]}.${version[1]}.${version[2]}`,canvas.width-Cam.toGuiScale(10),canvas.height-Cam.toGuiScale(95)+canvasBox.hidden*Cam.toGuiScale(80)),
	ctx.fillText(`${isPrivateBuild ? "" : "Evades Region Editor "}${version[3]}${version[0]}.${version[1]}.${version[2]}`,canvas.width-Cam.toGuiScale(10),canvas.height-Cam.toGuiScale(95)+canvasBox.hidden*Cam.toGuiScale(80))
	ctx.textAlign = "left";
	if (assetsLoaded.count / 8 < 1)
		ctx.fillRect(Cam.toGuiScale(10), canvas.height - Cam.toGuiScale(20), assetsLoaded.count / 8 * Cam.toGuiScale(200), Cam.toGuiScale(10)),
		ctx.fillText("Loading assets...", assetsLoaded.count / 8 * Cam.toGuiScale(200) + Cam.toGuiScale(15), canvas.height - Cam.toGuiScale(15));
	if (!playtesting)
		alertMessages=alertMessages.filter(e=>e.removeAfter>lastTime),
		alertMessages.map( (e, t, a) => {
			ctx.fillStyle = "function" === typeof e.color ? e.color(lastTime-e.removeAfter+e.duration*1e3) : e.color;
			ctx.strokeText(`${e.text}`, Cam.toGuiScale(10), canvas.height - Cam.toGuiScale(20) * (1+a.length - t), canvas.width - Cam.toGuiScale(20));
			ctx.fillText(`${e.text}`, Cam.toGuiScale(10), canvas.height - Cam.toGuiScale(20) * (1+a.length - t), canvas.width - Cam.toGuiScale(20));
		});
	ctx.lineJoin = "miter";
	ctx.textBaseline = "alphabetic";
	let v = `hsl(${lastTime/1e3*180}deg,100%,50%)`;
	ctx.strokeStyle = ctx.fillStyle = v,
	ctx.lineWidth=Cam.toGuiScale(2);
	ctx.beginPath();
	const mp = {x:canvas.width / 2 + mousePos.ex,y:canvas.height / 2 + mousePos.ey};
	if(playtesting && (!$e7009c797811e935$export$2e2bcd8739ae039.allowButtonPropagation && settings.enableMouseMovement) || (settings.toggleMouseMovement && $e7009c797811e935$export$2e2bcd8739ae039.mouseMovementToggled)){
		ctx.moveTo(mp.x,mp.y-Cam.toGuiScale(12));
		ctx.lineTo(mp.x,mp.y+Cam.toGuiScale(12));
		ctx.moveTo(mp.x-Cam.toGuiScale(12),mp.y);
		ctx.lineTo(mp.x+Cam.toGuiScale(12),mp.y);
	}else if(-1 !== "du".indexOf(selectMode)){
		ctx.moveTo(mp.x-Cam.toGuiScale(12),mp.y);
		ctx.lineTo(mp.x+Cam.toGuiScale(12),mp.y);
		arrow(ctx,mp.x,mp.y,mp.x,mp.y+Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x,mp.y-Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v);
	}else if(String(selectMode).startsWith("o")){
		let ang = Math.PI/2 * "rdlu".indexOf(selectMode.slice(1));
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16)*Math.cos(ang),mp.y+Cam.toGuiScale(16)*Math.sin(ang),Cam.toGuiScale(16),1,"#000",v);
	}else if(-1 !== "lr".indexOf(selectMode)){
		ctx.moveTo(mp.x,mp.y-Cam.toGuiScale(12));
		ctx.lineTo(mp.x,mp.y+Cam.toGuiScale(12));
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v);
	}else if(-1 !== "ul,dr".split(",").indexOf(selectMode)){
		let u = 1 / Math.sqrt(2);
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16)*u,mp.y-Cam.toGuiScale(16)*u,Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16)*u,mp.y+Cam.toGuiScale(16)*u,Cam.toGuiScale(16),1,"#000",v);
	}else if(-1 !== "ur,dl".split(",").indexOf(selectMode)){
		let u = 1 / Math.sqrt(2)
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16)*u,mp.y+Cam.toGuiScale(16)*u,Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16)*u,mp.y-Cam.toGuiScale(16)*u,Cam.toGuiScale(16),1,"#000",v);
	}else if("m" === selectMode){
		arrow(ctx,mp.x,mp.y,mp.x,mp.y+Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x,mp.y-Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v);
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v);
	}else if(selectMode === "x"){
		let u = 1 / Math.sqrt(2);
		ctx.moveTo(mp.x-Cam.toGuiScale(16)*u,mp.y-Cam.toGuiScale(16)*u);
		ctx.lineTo(mp.x+Cam.toGuiScale(16)*u,mp.y+Cam.toGuiScale(16)*u);
		ctx.moveTo(mp.x+Cam.toGuiScale(16),mp.y);
		ctx.arc(mp.x,mp.y,Cam.toGuiScale(16),0,Math.PI*2,false);
	}else if(selectMode === "p"){
		let a = [Math.cos(Math.PI*2/3),Math.sin(Math.PI*2/3)];
		ctx.moveTo(mp.x+Cam.toGuiScale(16),mp.y);
		ctx.lineTo(mp.x+Cam.toGuiScale(16)*a[0],mp.y+Cam.toGuiScale(16)*a[1]);
		ctx.lineTo(mp.x+Cam.toGuiScale(16)*a[0],mp.y-Cam.toGuiScale(16)*a[1]);
	}else if(null === selectMode){
		let u = 1 / Math.sqrt(2);
		arrow(ctx,mp.x+Cam.toGuiScale(16)*u,mp.y+Cam.toGuiScale(16)*u,mp.x,mp.y,Cam.toGuiScale(16),1,"#000",v);
	}else if(-1 !== "vh".indexOf(selectMode.slice(1))){
		selectMode.indexOf("v")!=-1&&(
		arrow(ctx,mp.x,mp.y,mp.x,mp.y+Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v),
		arrow(ctx,mp.x,mp.y,mp.x,mp.y-Cam.toGuiScale(16),Cam.toGuiScale(16),1,"#000",v));
		selectMode.indexOf("h")!=-1&&(
		arrow(ctx,mp.x,mp.y,mp.x+Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v),
		arrow(ctx,mp.x,mp.y,mp.x-Cam.toGuiScale(16),mp.y,Cam.toGuiScale(16),1,"#000",v));
	}
	ctx.closePath();
	ctx.fillStyle="black";
	ctx.stroke();
	"x" !== selectMode && ctx.fill();
	if(distortionsActive === true)renderGl();
};
